<?php

/* OCPlatformBundle:Advert:OussouOummou.html.twig */
class __TwigTemplate_5a106be8fcb6fbcc3d299c6a490764e99271deeb56d01224d3a3af5c7b17842f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("OCPlatformBundle::layout.html.twig", "OCPlatformBundle:Advert:OussouOummou.html.twig", 2);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4c5b610b875458438ee4e773512721a910c13b01ea76da22e30a7af24b2a8bce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4c5b610b875458438ee4e773512721a910c13b01ea76da22e30a7af24b2a8bce->enter($__internal_4c5b610b875458438ee4e773512721a910c13b01ea76da22e30a7af24b2a8bce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:OussouOummou.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4c5b610b875458438ee4e773512721a910c13b01ea76da22e30a7af24b2a8bce->leave($__internal_4c5b610b875458438ee4e773512721a910c13b01ea76da22e30a7af24b2a8bce_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_8e878994b076792c41dd4d64ba9335c8531b4244396c350ad02656c8e90b4337 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8e878994b076792c41dd4d64ba9335c8531b4244396c350ad02656c8e90b4337->enter($__internal_8e878994b076792c41dd4d64ba9335c8531b4244396c350ad02656c8e90b4337_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<h2>OussouTouré </h2>

<p>
Attention : cette page est <strong>confidentielle</strong>
</p>
";
        
        $__internal_8e878994b076792c41dd4d64ba9335c8531b4244396c350ad02656c8e90b4337->leave($__internal_8e878994b076792c41dd4d64ba9335c8531b4244396c350ad02656c8e90b4337_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:OussouOummou.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 2,);
    }

    public function getSource()
    {
        return "{# src/OC/PlatformBundle/Resources/view/Advert/OussouOummou.html.twig #}
{% extends \"OCPlatformBundle::layout.html.twig\" %}
{% block body %}
<h2>OussouTouré </h2>

<p>
Attention : cette page est <strong>confidentielle</strong>
</p>
{% endblock %}";
    }
}

<?php

/* ::layout.html.twig */
class __TwigTemplate_7e0253325f5429bc71a7bafef3864b6fedbf4f5f691949425ad37a3add13e166 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_316c0ed12cb43cf63f4173fa8a8881f4f88cad82116cb9bea43a4c75595c8391 = $this->env->getExtension("native_profiler");
        $__internal_316c0ed12cb43cf63f4173fa8a8881f4f88cad82116cb9bea43a4c75595c8391->enter($__internal_316c0ed12cb43cf63f4173fa8a8881f4f88cad82116cb9bea43a4c75595c8391_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::layout.html.twig"));

        // line 2
        echo "<!DOCTYPE html>
<html>
\t<head>
\t\t<meta charset=\"utf-8\" />
\t\t<title> ";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo " </title>
\t\t";
        // line 7
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 11
        echo "\t</head>
\t<body>
\t <div class=\"container\">
\t   <div id=\"header\" class=\"jumbotron\" style=\"margin-top : 70px\">
\t    <h1>Ma plateforme d'annonces! </h1>
\t    <p>Ce projet est propulsé par Symfony et construit grâce au MOOC OpenClassrooms et SensioLabs.
\t    </p>
\t    <p>
\t     <a class=\"btn btn-primary btn-lg\" target=\"_blank\" href=\"https://openclassrooms.com/courses/developpez-votre-site-web-avec-le-framework-symfony2\">
          Participer au MOOC »
        </a>
        </p>
        </div>
\t   <div class=\"row\">
\t      <div id=\"menu\" class=\"col-md-3\">
\t        <h3>Les annonces</h3>
\t        <ul class=\"nav nav-pills nav-stacked\">
\t          <li><a href=\"";
        // line 28
        echo $this->env->getExtension('routing')->getPath("oc_platform_home");
        echo "\">Accueil</a></li>
\t          ";
        // line 30
        echo "\t        </ul>

\t        <h4>Dernières annonces</h4>
\t        ";
        // line 33
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("OCPlatformBundle:Advert:menu", array("limit" => 3)));
        echo "
      </div>
      <div id=\"content\" class=\"col-md-9\">
        ";
        // line 36
        $this->displayBlock('body', $context, $blocks);
        // line 38
        echo "      </div>
    </div>

    <hr>

    <footer>
      <p>The sky's the limit © ";
        // line 44
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " and beyond.</p>
    </footer>
  </div>

  ";
        // line 48
        $this->displayBlock('javascripts', $context, $blocks);
        // line 53
        echo "
</body>
</html>";
        
        $__internal_316c0ed12cb43cf63f4173fa8a8881f4f88cad82116cb9bea43a4c75595c8391->leave($__internal_316c0ed12cb43cf63f4173fa8a8881f4f88cad82116cb9bea43a4c75595c8391_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_d34ab13492e445fc3dc60b587a973f4cfef8f5ccea52573050361f6b0d62ff76 = $this->env->getExtension("native_profiler");
        $__internal_d34ab13492e445fc3dc60b587a973f4cfef8f5ccea52573050361f6b0d62ff76->enter($__internal_d34ab13492e445fc3dc60b587a973f4cfef8f5ccea52573050361f6b0d62ff76_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo " OC Plateforme ";
        
        $__internal_d34ab13492e445fc3dc60b587a973f4cfef8f5ccea52573050361f6b0d62ff76->leave($__internal_d34ab13492e445fc3dc60b587a973f4cfef8f5ccea52573050361f6b0d62ff76_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_e866dd6ff1bd8d58fae777a14ef62c0795b4920a77f4285376d80caea5f9485c = $this->env->getExtension("native_profiler");
        $__internal_e866dd6ff1bd8d58fae777a14ef62c0795b4920a77f4285376d80caea5f9485c->enter($__internal_e866dd6ff1bd8d58fae777a14ef62c0795b4920a77f4285376d80caea5f9485c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "\t\t";
        // line 9
        echo "         <link rel=\"stylesheet\"  href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css\">
         ";
        
        $__internal_e866dd6ff1bd8d58fae777a14ef62c0795b4920a77f4285376d80caea5f9485c->leave($__internal_e866dd6ff1bd8d58fae777a14ef62c0795b4920a77f4285376d80caea5f9485c_prof);

    }

    // line 36
    public function block_body($context, array $blocks = array())
    {
        $__internal_9950c75c033a477ec355438947993eedb150db048f6403ea5cc251d10d72f7d6 = $this->env->getExtension("native_profiler");
        $__internal_9950c75c033a477ec355438947993eedb150db048f6403ea5cc251d10d72f7d6->enter($__internal_9950c75c033a477ec355438947993eedb150db048f6403ea5cc251d10d72f7d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 37
        echo "        ";
        
        $__internal_9950c75c033a477ec355438947993eedb150db048f6403ea5cc251d10d72f7d6->leave($__internal_9950c75c033a477ec355438947993eedb150db048f6403ea5cc251d10d72f7d6_prof);

    }

    // line 48
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_f955ca7cf2b307e354874998d7b070f0b8f82c177d3d7c9b1b8f5580e711899b = $this->env->getExtension("native_profiler");
        $__internal_f955ca7cf2b307e354874998d7b070f0b8f82c177d3d7c9b1b8f5580e711899b->enter($__internal_f955ca7cf2b307e354874998d7b070f0b8f82c177d3d7c9b1b8f5580e711899b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 49
        echo "    ";
        // line 50
        echo "    <script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>
    <script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js\"></script>
  ";
        
        $__internal_f955ca7cf2b307e354874998d7b070f0b8f82c177d3d7c9b1b8f5580e711899b->leave($__internal_f955ca7cf2b307e354874998d7b070f0b8f82c177d3d7c9b1b8f5580e711899b_prof);

    }

    public function getTemplateName()
    {
        return "::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  149 => 50,  147 => 49,  141 => 48,  134 => 37,  128 => 36,  120 => 9,  118 => 8,  112 => 7,  100 => 6,  91 => 53,  89 => 48,  82 => 44,  74 => 38,  72 => 36,  66 => 33,  61 => 30,  57 => 28,  38 => 11,  36 => 7,  32 => 6,  26 => 2,);
    }
}
/* {# app/Resources/views/layout.html.twig #}*/
/* <!DOCTYPE html>*/
/* <html>*/
/* 	<head>*/
/* 		<meta charset="utf-8" />*/
/* 		<title> {% block title %} OC Plateforme {% endblock %} </title>*/
/* 		{% block stylesheets %}*/
/* 		{# On charge le CSS de bootstrap depuis le site directement #}*/
/*          <link rel="stylesheet"  href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">*/
/*          {% endblock %}*/
/* 	</head>*/
/* 	<body>*/
/* 	 <div class="container">*/
/* 	   <div id="header" class="jumbotron" style="margin-top : 70px">*/
/* 	    <h1>Ma plateforme d'annonces! </h1>*/
/* 	    <p>Ce projet est propulsé par Symfony et construit grâce au MOOC OpenClassrooms et SensioLabs.*/
/* 	    </p>*/
/* 	    <p>*/
/* 	     <a class="btn btn-primary btn-lg" target="_blank" href="https://openclassrooms.com/courses/developpez-votre-site-web-avec-le-framework-symfony2">*/
/*           Participer au MOOC »*/
/*         </a>*/
/*         </p>*/
/*         </div>*/
/* 	   <div class="row">*/
/* 	      <div id="menu" class="col-md-3">*/
/* 	        <h3>Les annonces</h3>*/
/* 	        <ul class="nav nav-pills nav-stacked">*/
/* 	          <li><a href="{{ path('oc_platform_home') }}">Accueil</a></li>*/
/* 	          {# <li><a href="{{ path('oc_platform_add') }}">Ajouter une annonce</a></li> #}*/
/* 	        </ul>*/
/* */
/* 	        <h4>Dernières annonces</h4>*/
/* 	        {{ render(controller("OCPlatformBundle:Advert:menu", {'limit': 3})) }}*/
/*       </div>*/
/*       <div id="content" class="col-md-9">*/
/*         {% block body %}*/
/*         {% endblock %}*/
/*       </div>*/
/*     </div>*/
/* */
/*     <hr>*/
/* */
/*     <footer>*/
/*       <p>The sky's the limit © {{ 'now'|date('Y') }} and beyond.</p>*/
/*     </footer>*/
/*   </div>*/
/* */
/*   {% block javascripts %}*/
/*     {# Ajoutez ces lignes JavaScript si vous comptez vous servir des fonctionnalités du bootstrap Twitter #}*/
/*     <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>*/
/*     <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>*/
/*   {% endblock %}*/
/* */
/* </body>*/
/* </html>*/

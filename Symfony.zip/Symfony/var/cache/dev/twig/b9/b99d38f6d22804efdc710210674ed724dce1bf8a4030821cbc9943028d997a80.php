<?php

/* OCPlatformBundle:Advert:form.html.twig */
class __TwigTemplate_89b7aa666920418d585f615db1de88401369c38617cb204170e7c9ad3558663c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_07d4f45fd4ea5e5d5741e9b1e162bb8e02bbe3f7d36ba47f96e32cece8c2c6e9 = $this->env->getExtension("native_profiler");
        $__internal_07d4f45fd4ea5e5d5741e9b1e162bb8e02bbe3f7d36ba47f96e32cece8c2c6e9->enter($__internal_07d4f45fd4ea5e5d5741e9b1e162bb8e02bbe3f7d36ba47f96e32cece8c2c6e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:form.html.twig"));

        // line 2
        echo "

";
        // line 7
        echo "

<h3>Formulaire d'annonce</h3>


";
        // line 15
        echo "
<div class=\"well\">

  Ici se trouvera le formulaire.

</div>";
        
        $__internal_07d4f45fd4ea5e5d5741e9b1e162bb8e02bbe3f7d36ba47f96e32cece8c2c6e9->leave($__internal_07d4f45fd4ea5e5d5741e9b1e162bb8e02bbe3f7d36ba47f96e32cece8c2c6e9_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:form.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  33 => 15,  26 => 7,  22 => 2,);
    }
}
/* {# src/OC/PlatformBundle/Resources/views/Advert/form.html.twig #}*/
/* */
/* */
/* {# Cette vue n'hérite de personne, elle sera incluse par d'autres vues qui,*/
/*    elles, hériteront probablement du layout. Je dis « probablement » car,*/
/*    ici pour cette vue, on n'en sait rien et c'est une info qui ne nous concerne pas. #}*/
/* */
/* */
/* <h3>Formulaire d'annonce</h3>*/
/* */
/* */
/* {# On laisse vide la vue pour l'instant, on la comblera plus tard*/
/* */
/*    lorsqu'on saura afficher un formulaire. #}*/
/* */
/* <div class="well">*/
/* */
/*   Ici se trouvera le formulaire.*/
/* */
/* </div>*/

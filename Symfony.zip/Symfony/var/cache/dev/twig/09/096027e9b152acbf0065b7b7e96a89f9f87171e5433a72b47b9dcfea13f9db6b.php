<?php

/* OCPlatformBundle:Advert:edit.html.twig */
class __TwigTemplate_261f1fe8d6e1ffdf0e3720810e5b088d7c9f0ab064d124f30825ce99025c3572 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("OCPlatformBundle::layout.html.twig", "OCPlatformBundle:Advert:edit.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'ocplatform_body' => array($this, 'block_ocplatform_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6ea4ca08402748b0937a90e149229b95d4b39d1c33a8561d2d32fa6b7029acef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6ea4ca08402748b0937a90e149229b95d4b39d1c33a8561d2d32fa6b7029acef->enter($__internal_6ea4ca08402748b0937a90e149229b95d4b39d1c33a8561d2d32fa6b7029acef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6ea4ca08402748b0937a90e149229b95d4b39d1c33a8561d2d32fa6b7029acef->leave($__internal_6ea4ca08402748b0937a90e149229b95d4b39d1c33a8561d2d32fa6b7029acef_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_51323103ca9bdb2c19bfef42d26ad8bf81eadc1f485e3ef050663a9828168117 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_51323103ca9bdb2c19bfef42d26ad8bf81eadc1f485e3ef050663a9828168117->enter($__internal_51323103ca9bdb2c19bfef42d26ad8bf81eadc1f485e3ef050663a9828168117_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "  Modifier une annonce - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_51323103ca9bdb2c19bfef42d26ad8bf81eadc1f485e3ef050663a9828168117->leave($__internal_51323103ca9bdb2c19bfef42d26ad8bf81eadc1f485e3ef050663a9828168117_prof);

    }

    // line 9
    public function block_ocplatform_body($context, array $blocks = array())
    {
        $__internal_7a83044572809522fbf4dcd76968ab38863ac4827115d9595b5d4c015715257b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7a83044572809522fbf4dcd76968ab38863ac4827115d9595b5d4c015715257b->enter($__internal_7a83044572809522fbf4dcd76968ab38863ac4827115d9595b5d4c015715257b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        // line 10
        echo "
  <h2>Modifier une annonce</h2>

  ";
        // line 13
        echo twig_include($this->env, $context, "OCPlatformBundle:Advert:form.html.twig");
        echo "

  <p>
    Vous éditez une annonce déjà existante, merci de ne pas changer
    l'esprit général de l'annonce déjà publiée.
  </p>

  <p>
    <a href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_view", array("id" => $this->getAttribute((isset($context["advert"]) ? $context["advert"] : $this->getContext($context, "advert")), "id", array()))), "html", null, true);
        echo "\" class=\"btn btn-default\">
      <i class=\"glyphicon glyphicon-chevron-left\"></i>
      Retour à l'annonce
    </a>
  </p>

";
        
        $__internal_7a83044572809522fbf4dcd76968ab38863ac4827115d9595b5d4c015715257b->leave($__internal_7a83044572809522fbf4dcd76968ab38863ac4827115d9595b5d4c015715257b_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 21,  62 => 13,  57 => 10,  51 => 9,  41 => 6,  35 => 5,  11 => 3,);
    }

    public function getSource()
    {
        return "{# src/OC/PlatformBundle/Resources/views/Advert/edit.html.twig #}

{% extends \"OCPlatformBundle::layout.html.twig\" %}

{% block title %}
  Modifier une annonce - {{ parent() }}
{% endblock %}

{% block ocplatform_body %}

  <h2>Modifier une annonce</h2>

  {{ include(\"OCPlatformBundle:Advert:form.html.twig\") }}

  <p>
    Vous éditez une annonce déjà existante, merci de ne pas changer
    l'esprit général de l'annonce déjà publiée.
  </p>

  <p>
    <a href=\"{{ path('oc_platform_view', {'id': advert.id}) }}\" class=\"btn btn-default\">
      <i class=\"glyphicon glyphicon-chevron-left\"></i>
      Retour à l'annonce
    </a>
  </p>

{% endblock %}";
    }
}

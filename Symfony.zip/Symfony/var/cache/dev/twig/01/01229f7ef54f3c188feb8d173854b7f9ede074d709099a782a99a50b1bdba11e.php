<?php

/* OCPlatformBundle::layout.html.twig */
class __TwigTemplate_486bc1773234e84569a57906a16eb32424cf6cca820a46bfef309d629528265a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("::layout.html.twig", "OCPlatformBundle::layout.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'ocplatform_body' => array($this, 'block_ocplatform_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_03e1e73dfa563b4718639d69986613858d75d8d431cbc8bc3834cff07e78b552 = $this->env->getExtension("native_profiler");
        $__internal_03e1e73dfa563b4718639d69986613858d75d8d431cbc8bc3834cff07e78b552->enter($__internal_03e1e73dfa563b4718639d69986613858d75d8d431cbc8bc3834cff07e78b552_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle::layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_03e1e73dfa563b4718639d69986613858d75d8d431cbc8bc3834cff07e78b552->leave($__internal_03e1e73dfa563b4718639d69986613858d75d8d431cbc8bc3834cff07e78b552_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_4fde63198a84821b4f4b522e16be4b27ec7ce39e55270ea1ef7b9ee6b3f8aa24 = $this->env->getExtension("native_profiler");
        $__internal_4fde63198a84821b4f4b522e16be4b27ec7ce39e55270ea1ef7b9ee6b3f8aa24->enter($__internal_4fde63198a84821b4f4b522e16be4b27ec7ce39e55270ea1ef7b9ee6b3f8aa24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "  Annonces - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_4fde63198a84821b4f4b522e16be4b27ec7ce39e55270ea1ef7b9ee6b3f8aa24->leave($__internal_4fde63198a84821b4f4b522e16be4b27ec7ce39e55270ea1ef7b9ee6b3f8aa24_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_2bbc64c5508fcc5df805cf88624cd5340843deb7a7252b7ecf386de0ea0eeae8 = $this->env->getExtension("native_profiler");
        $__internal_2bbc64c5508fcc5df805cf88624cd5340843deb7a7252b7ecf386de0ea0eeae8->enter($__internal_2bbc64c5508fcc5df805cf88624cd5340843deb7a7252b7ecf386de0ea0eeae8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "
  ";
        // line 12
        echo "  <h1>Annonces</h1>

  <hr>

  ";
        // line 17
        echo "  ";
        $this->displayBlock('ocplatform_body', $context, $blocks);
        // line 19
        echo "
";
        
        $__internal_2bbc64c5508fcc5df805cf88624cd5340843deb7a7252b7ecf386de0ea0eeae8->leave($__internal_2bbc64c5508fcc5df805cf88624cd5340843deb7a7252b7ecf386de0ea0eeae8_prof);

    }

    // line 17
    public function block_ocplatform_body($context, array $blocks = array())
    {
        $__internal_d4900ef60f8fc71264f1d03934c19ec0d97d9514f23b04f79828db7dfc8f0036 = $this->env->getExtension("native_profiler");
        $__internal_d4900ef60f8fc71264f1d03934c19ec0d97d9514f23b04f79828db7dfc8f0036->enter($__internal_d4900ef60f8fc71264f1d03934c19ec0d97d9514f23b04f79828db7dfc8f0036_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        // line 18
        echo "  ";
        
        $__internal_d4900ef60f8fc71264f1d03934c19ec0d97d9514f23b04f79828db7dfc8f0036->leave($__internal_d4900ef60f8fc71264f1d03934c19ec0d97d9514f23b04f79828db7dfc8f0036_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 18,  78 => 17,  70 => 19,  67 => 17,  61 => 12,  58 => 10,  52 => 9,  42 => 6,  36 => 5,  11 => 3,);
    }
}
/* {# src/OC/PlatformBundle/Resources/views/layout.html.twig #}*/
/* */
/* {% extends "::layout.html.twig" %}*/
/* */
/* {% block title %}*/
/*   Annonces - {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/* */
/*   {# On définit un sous-titre commun à toutes les pages du bundle, par exemple #}*/
/*   <h1>Annonces</h1>*/
/* */
/*   <hr>*/
/* */
/*   {# On définit un nouveau bloc, que les vues du bundle pourront remplir #}*/
/*   {% block ocplatform_body %}*/
/*   {% endblock %}*/
/* */
/* {% endblock %}*/

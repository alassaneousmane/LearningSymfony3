<?php

/* OCPlatformBundle::layout.html.twig */
class __TwigTemplate_00296ab68271afd3b11f17c2f87a3aa63e6dceb63369a1d18b47f6013b307a4e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("::layout.html.twig", "OCPlatformBundle::layout.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'ocplatform_body' => array($this, 'block_ocplatform_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f7960fde38eff3d71e7c1557a55ed298911def3979faf5b6432a4fcbd80212fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f7960fde38eff3d71e7c1557a55ed298911def3979faf5b6432a4fcbd80212fe->enter($__internal_f7960fde38eff3d71e7c1557a55ed298911def3979faf5b6432a4fcbd80212fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle::layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f7960fde38eff3d71e7c1557a55ed298911def3979faf5b6432a4fcbd80212fe->leave($__internal_f7960fde38eff3d71e7c1557a55ed298911def3979faf5b6432a4fcbd80212fe_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_7127ad2cce734a302a1dc90af5060a895a0f5ebe263cd4f43ae23471336fa500 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7127ad2cce734a302a1dc90af5060a895a0f5ebe263cd4f43ae23471336fa500->enter($__internal_7127ad2cce734a302a1dc90af5060a895a0f5ebe263cd4f43ae23471336fa500_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "  Annonces - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_7127ad2cce734a302a1dc90af5060a895a0f5ebe263cd4f43ae23471336fa500->leave($__internal_7127ad2cce734a302a1dc90af5060a895a0f5ebe263cd4f43ae23471336fa500_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_c8a306ac206dd56a267312c3af7a6051f150b000535e2f81c6dbcbdba3031f4f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c8a306ac206dd56a267312c3af7a6051f150b000535e2f81c6dbcbdba3031f4f->enter($__internal_c8a306ac206dd56a267312c3af7a6051f150b000535e2f81c6dbcbdba3031f4f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "
  ";
        // line 12
        echo "  <h1>Annonces</h1>

  <hr>

  ";
        // line 17
        echo "  ";
        $this->displayBlock('ocplatform_body', $context, $blocks);
        // line 19
        echo "
";
        
        $__internal_c8a306ac206dd56a267312c3af7a6051f150b000535e2f81c6dbcbdba3031f4f->leave($__internal_c8a306ac206dd56a267312c3af7a6051f150b000535e2f81c6dbcbdba3031f4f_prof);

    }

    // line 17
    public function block_ocplatform_body($context, array $blocks = array())
    {
        $__internal_eca5daca4984638eb0f783974b545a6bcd5ea2d9fc02d539860d57a4cb002e87 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eca5daca4984638eb0f783974b545a6bcd5ea2d9fc02d539860d57a4cb002e87->enter($__internal_eca5daca4984638eb0f783974b545a6bcd5ea2d9fc02d539860d57a4cb002e87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        // line 18
        echo "  ";
        
        $__internal_eca5daca4984638eb0f783974b545a6bcd5ea2d9fc02d539860d57a4cb002e87->leave($__internal_eca5daca4984638eb0f783974b545a6bcd5ea2d9fc02d539860d57a4cb002e87_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 18,  78 => 17,  70 => 19,  67 => 17,  61 => 12,  58 => 10,  52 => 9,  42 => 6,  36 => 5,  11 => 3,);
    }

    public function getSource()
    {
        return "{# src/OC/PlatformBundle/Resources/views/layout.html.twig #}

{% extends \"::layout.html.twig\" %}

{% block title %}
  Annonces - {{ parent() }}
{% endblock %}

{% block body %}

  {# On définit un sous-titre commun à toutes les pages du bundle, par exemple #}
  <h1>Annonces</h1>

  <hr>

  {# On définit un nouveau bloc, que les vues du bundle pourront remplir #}
  {% block ocplatform_body %}
  {% endblock %}

{% endblock %}";
    }
}

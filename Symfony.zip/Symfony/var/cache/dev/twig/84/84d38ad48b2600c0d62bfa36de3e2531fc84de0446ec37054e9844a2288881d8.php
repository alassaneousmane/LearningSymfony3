<?php

/* OCPlatformBundle:Advert:form.html.twig */
class __TwigTemplate_8320f4897bff8055ae69c986ebb02a9913b9dfb126b42601a1c050c5aa69447c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_19a8ce4ab77c96863cf136c265cd03eb56f25431931f030f79a0eeb41ee70134 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_19a8ce4ab77c96863cf136c265cd03eb56f25431931f030f79a0eeb41ee70134->enter($__internal_19a8ce4ab77c96863cf136c265cd03eb56f25431931f030f79a0eeb41ee70134_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:form.html.twig"));

        // line 2
        echo "

";
        // line 7
        echo "

<h3>Formulaire d'annonce</h3>


";
        // line 15
        echo "
<div class=\"well\">

  Ici se trouvera le formulaire.

</div>";
        
        $__internal_19a8ce4ab77c96863cf136c265cd03eb56f25431931f030f79a0eeb41ee70134->leave($__internal_19a8ce4ab77c96863cf136c265cd03eb56f25431931f030f79a0eeb41ee70134_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:form.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  33 => 15,  26 => 7,  22 => 2,);
    }

    public function getSource()
    {
        return "{# src/OC/PlatformBundle/Resources/views/Advert/form.html.twig #}


{# Cette vue n'hérite de personne, elle sera incluse par d'autres vues qui,
   elles, hériteront probablement du layout. Je dis « probablement » car,
   ici pour cette vue, on n'en sait rien et c'est une info qui ne nous concerne pas. #}


<h3>Formulaire d'annonce</h3>


{# On laisse vide la vue pour l'instant, on la comblera plus tard

   lorsqu'on saura afficher un formulaire. #}

<div class=\"well\">

  Ici se trouvera le formulaire.

</div>";
    }
}

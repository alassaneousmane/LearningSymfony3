<?php

/* OCPlatformBundle:Advert:edit.html.twig */
class __TwigTemplate_04ac5a149efd321cae12c558a690427d6843aa9500d85f43b1c3a3d8d799ee37 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("OCPlatformBundle::layout.html.twig", "OCPlatformBundle:Advert:edit.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'ocplatform_body' => array($this, 'block_ocplatform_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c0e0dd4e8e713cda60136914fef85db50d59c11a78e1c8d8677cb521cf32fc71 = $this->env->getExtension("native_profiler");
        $__internal_c0e0dd4e8e713cda60136914fef85db50d59c11a78e1c8d8677cb521cf32fc71->enter($__internal_c0e0dd4e8e713cda60136914fef85db50d59c11a78e1c8d8677cb521cf32fc71_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c0e0dd4e8e713cda60136914fef85db50d59c11a78e1c8d8677cb521cf32fc71->leave($__internal_c0e0dd4e8e713cda60136914fef85db50d59c11a78e1c8d8677cb521cf32fc71_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_6f93e5fe001ba3488ccf91a79ccd12381af0b9030e2f3c267df363e767aa53b3 = $this->env->getExtension("native_profiler");
        $__internal_6f93e5fe001ba3488ccf91a79ccd12381af0b9030e2f3c267df363e767aa53b3->enter($__internal_6f93e5fe001ba3488ccf91a79ccd12381af0b9030e2f3c267df363e767aa53b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "  Modifier une annonce - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_6f93e5fe001ba3488ccf91a79ccd12381af0b9030e2f3c267df363e767aa53b3->leave($__internal_6f93e5fe001ba3488ccf91a79ccd12381af0b9030e2f3c267df363e767aa53b3_prof);

    }

    // line 9
    public function block_ocplatform_body($context, array $blocks = array())
    {
        $__internal_91796809cc7e6ddedc7ed667c71ca9251d4529baad665ebd36384256c7e82394 = $this->env->getExtension("native_profiler");
        $__internal_91796809cc7e6ddedc7ed667c71ca9251d4529baad665ebd36384256c7e82394->enter($__internal_91796809cc7e6ddedc7ed667c71ca9251d4529baad665ebd36384256c7e82394_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        // line 10
        echo "
  <h2>Modifier une annonce</h2>

  ";
        // line 13
        echo twig_include($this->env, $context, "OCPlatformBundle:Advert:form.html.twig");
        echo "

  <p>
    Vous éditez une annonce déjà existante, merci de ne pas changer
    l'esprit général de l'annonce déjà publiée.
  </p>

  <p>
    <a href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("oc_platform_view", array("id" => $this->getAttribute((isset($context["advert"]) ? $context["advert"] : $this->getContext($context, "advert")), "id", array()))), "html", null, true);
        echo "\" class=\"btn btn-default\">
      <i class=\"glyphicon glyphicon-chevron-left\"></i>
      Retour à l'annonce
    </a>
  </p>

";
        
        $__internal_91796809cc7e6ddedc7ed667c71ca9251d4529baad665ebd36384256c7e82394->leave($__internal_91796809cc7e6ddedc7ed667c71ca9251d4529baad665ebd36384256c7e82394_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 21,  62 => 13,  57 => 10,  51 => 9,  41 => 6,  35 => 5,  11 => 3,);
    }
}
/* {# src/OC/PlatformBundle/Resources/views/Advert/edit.html.twig #}*/
/* */
/* {% extends "OCPlatformBundle::layout.html.twig" %}*/
/* */
/* {% block title %}*/
/*   Modifier une annonce - {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block ocplatform_body %}*/
/* */
/*   <h2>Modifier une annonce</h2>*/
/* */
/*   {{ include("OCPlatformBundle:Advert:form.html.twig") }}*/
/* */
/*   <p>*/
/*     Vous éditez une annonce déjà existante, merci de ne pas changer*/
/*     l'esprit général de l'annonce déjà publiée.*/
/*   </p>*/
/* */
/*   <p>*/
/*     <a href="{{ path('oc_platform_view', {'id': advert.id}) }}" class="btn btn-default">*/
/*       <i class="glyphicon glyphicon-chevron-left"></i>*/
/*       Retour à l'annonce*/
/*     </a>*/
/*   </p>*/
/* */
/* {% endblock %}*/

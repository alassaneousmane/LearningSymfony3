<?php

/* ::layout.html.twig */
class __TwigTemplate_b20ce110832a53e0ce114bd54c20ff508ace5ec07db2a76c80e7985849d90382 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4e0d1e04060007247788dc0841f03797cb886fd93ef65f6066a00769ac45fe7e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4e0d1e04060007247788dc0841f03797cb886fd93ef65f6066a00769ac45fe7e->enter($__internal_4e0d1e04060007247788dc0841f03797cb886fd93ef65f6066a00769ac45fe7e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::layout.html.twig"));

        // line 2
        echo "<!DOCTYPE html>
<html>
\t<head>
\t\t<meta charset=\"utf-8\" />
\t\t<title> ";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo " </title>
\t\t";
        // line 7
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 11
        echo "\t</head>
\t<body>
\t <div class=\"container\">
\t   <div class=\"header clearfix\">
        <nav style=\"margin-top : 40px\">
          <ul class=\"nav nav-pills pull-right\">
            <li role=\"presentation\" class=\"active\"><a href=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_home");
        echo "\">Home</a></li>
            <li role=\"presentation\"><a href=\"#\">About</a></li>
            <li role=\"presentation\"><a href=\"#\">Contact</a></li>
          </ul>
        </nav>
        <h3 class=\"text-muted\">Dév OusmaneALaSSANe - Aujourd'hui : ";
        // line 22
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "d/m/Y"), "html", null, true);
        echo "</h3>
      </div>
\t   <div id=\"header\" class=\"jumbotron\" style=\"margin-top : 70px\">
\t    <h1>Ma plateforme d'annonces! </h1>
\t    <p>Ce projet est propulsé par Symfony 3 et construit grâce au MOOC OpenClassrooms et SensioLabs.
\t    </p>
\t    <p>
\t     <a class=\"btn btn-primary btn-lg\" target=\"_blank\" href=\"https://openclassrooms.com/courses/developpez-votre-site-web-avec-le-framework-symfony2\">
          Participer au MOOC »
        </a>
        </p>
        </div>
\t   <div class=\"row\">
\t      <div id=\"menu\" class=\"col-md-3\">
\t        <h3>Les annonces</h3>
\t        <ul class=\"nav nav-pills nav-stacked\">
\t          <li><a href=\"";
        // line 38
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_home");
        echo "\">Accueil</a></li>
\t          ";
        // line 40
        echo "\t        </ul>

\t        <h4>Dernières annonces</h4>
\t        ";
        // line 43
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->controller("OCPlatformBundle:Advert:menu", array("limit" => 3)));
        echo "
      </div>
      <div id=\"content\" class=\"col-md-9\">
        ";
        // line 46
        $this->displayBlock('body', $context, $blocks);
        // line 48
        echo "      </div>
    </div>

    <hr>

    <footer>
      <p>The sky's the limit © ";
        // line 54
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " and beyond.<br/>Responsable du site : ";
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, (isset($context["webmaster"]) ? $context["webmaster"] : $this->getContext($context, "webmaster"))), "html", null, true);
        echo "</p>
    </footer>
  </div>

  ";
        // line 58
        $this->displayBlock('javascripts', $context, $blocks);
        // line 63
        echo "
</body>
</html>";
        
        $__internal_4e0d1e04060007247788dc0841f03797cb886fd93ef65f6066a00769ac45fe7e->leave($__internal_4e0d1e04060007247788dc0841f03797cb886fd93ef65f6066a00769ac45fe7e_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_28e016f2339d6a6060fddc1c2ac7fddce1e26e9b75391a1f577e1fdfd697837b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_28e016f2339d6a6060fddc1c2ac7fddce1e26e9b75391a1f577e1fdfd697837b->enter($__internal_28e016f2339d6a6060fddc1c2ac7fddce1e26e9b75391a1f577e1fdfd697837b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo " OC Plateforme ";
        
        $__internal_28e016f2339d6a6060fddc1c2ac7fddce1e26e9b75391a1f577e1fdfd697837b->leave($__internal_28e016f2339d6a6060fddc1c2ac7fddce1e26e9b75391a1f577e1fdfd697837b_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_76196d0204abb594df8a9ae9f36c1983e7ebee3eb2ea7151ed608ed4249ceacb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_76196d0204abb594df8a9ae9f36c1983e7ebee3eb2ea7151ed608ed4249ceacb->enter($__internal_76196d0204abb594df8a9ae9f36c1983e7ebee3eb2ea7151ed608ed4249ceacb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "\t\t";
        // line 9
        echo "         <link rel=\"stylesheet\"  href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css\">
         ";
        
        $__internal_76196d0204abb594df8a9ae9f36c1983e7ebee3eb2ea7151ed608ed4249ceacb->leave($__internal_76196d0204abb594df8a9ae9f36c1983e7ebee3eb2ea7151ed608ed4249ceacb_prof);

    }

    // line 46
    public function block_body($context, array $blocks = array())
    {
        $__internal_bbdf367cb27139dfdf19828875937ed2a6f0b7993413ebada6ea7dac3a764e9f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bbdf367cb27139dfdf19828875937ed2a6f0b7993413ebada6ea7dac3a764e9f->enter($__internal_bbdf367cb27139dfdf19828875937ed2a6f0b7993413ebada6ea7dac3a764e9f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 47
        echo "        ";
        
        $__internal_bbdf367cb27139dfdf19828875937ed2a6f0b7993413ebada6ea7dac3a764e9f->leave($__internal_bbdf367cb27139dfdf19828875937ed2a6f0b7993413ebada6ea7dac3a764e9f_prof);

    }

    // line 58
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_7e40d8927cab02cbc136bd1c0f47c463226435eb2c99dc25fa5760074ff64a75 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7e40d8927cab02cbc136bd1c0f47c463226435eb2c99dc25fa5760074ff64a75->enter($__internal_7e40d8927cab02cbc136bd1c0f47c463226435eb2c99dc25fa5760074ff64a75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 59
        echo "    ";
        // line 60
        echo "    <script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>
    <script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js\"></script>
  ";
        
        $__internal_7e40d8927cab02cbc136bd1c0f47c463226435eb2c99dc25fa5760074ff64a75->leave($__internal_7e40d8927cab02cbc136bd1c0f47c463226435eb2c99dc25fa5760074ff64a75_prof);

    }

    public function getTemplateName()
    {
        return "::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  167 => 60,  165 => 59,  159 => 58,  152 => 47,  146 => 46,  138 => 9,  136 => 8,  130 => 7,  118 => 6,  109 => 63,  107 => 58,  98 => 54,  90 => 48,  88 => 46,  82 => 43,  77 => 40,  73 => 38,  54 => 22,  46 => 17,  38 => 11,  36 => 7,  32 => 6,  26 => 2,);
    }

    public function getSource()
    {
        return "{# app/Resources/views/layout.html.twig #}
<!DOCTYPE html>
<html>
\t<head>
\t\t<meta charset=\"utf-8\" />
\t\t<title> {% block title %} OC Plateforme {% endblock %} </title>
\t\t{% block stylesheets %}
\t\t{# On charge le CSS de bootstrap depuis le site directement #}
         <link rel=\"stylesheet\"  href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css\">
         {% endblock %}
\t</head>
\t<body>
\t <div class=\"container\">
\t   <div class=\"header clearfix\">
        <nav style=\"margin-top : 40px\">
          <ul class=\"nav nav-pills pull-right\">
            <li role=\"presentation\" class=\"active\"><a href=\"{{ path('oc_platform_home') }}\">Home</a></li>
            <li role=\"presentation\"><a href=\"#\">About</a></li>
            <li role=\"presentation\"><a href=\"#\">Contact</a></li>
          </ul>
        </nav>
        <h3 class=\"text-muted\">Dév OusmaneALaSSANe - Aujourd'hui : {{ \"now\"|date('d/m/Y') }}</h3>
      </div>
\t   <div id=\"header\" class=\"jumbotron\" style=\"margin-top : 70px\">
\t    <h1>Ma plateforme d'annonces! </h1>
\t    <p>Ce projet est propulsé par Symfony 3 et construit grâce au MOOC OpenClassrooms et SensioLabs.
\t    </p>
\t    <p>
\t     <a class=\"btn btn-primary btn-lg\" target=\"_blank\" href=\"https://openclassrooms.com/courses/developpez-votre-site-web-avec-le-framework-symfony2\">
          Participer au MOOC »
        </a>
        </p>
        </div>
\t   <div class=\"row\">
\t      <div id=\"menu\" class=\"col-md-3\">
\t        <h3>Les annonces</h3>
\t        <ul class=\"nav nav-pills nav-stacked\">
\t          <li><a href=\"{{ path('oc_platform_home') }}\">Accueil</a></li>
\t          {# <li><a href=\"{{ path('oc_platform_add') }}\">Ajouter une annonce</a></li> #}
\t        </ul>

\t        <h4>Dernières annonces</h4>
\t        {{ render(controller(\"OCPlatformBundle:Advert:menu\", {'limit': 3})) }}
      </div>
      <div id=\"content\" class=\"col-md-9\">
        {% block body %}
        {% endblock %}
      </div>
    </div>

    <hr>

    <footer>
      <p>The sky's the limit © {{ 'now'|date('Y') }} and beyond.<br/>Responsable du site : {{ webmaster|upper }}</p>
    </footer>
  </div>

  {% block javascripts %}
    {# Ajoutez ces lignes JavaScript si vous comptez vous servir des fonctionnalités du bootstrap Twitter #}
    <script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>
    <script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js\"></script>
  {% endblock %}

</body>
</html>";
    }
}

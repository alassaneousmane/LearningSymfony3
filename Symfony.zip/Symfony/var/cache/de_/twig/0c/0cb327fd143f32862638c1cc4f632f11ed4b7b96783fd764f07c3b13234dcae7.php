<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_d3d8f75883810a9a89d7dfb9f83a3423f02f9ba94fa5b9be9ffeb5b8a21c0899 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_644cda8bad9b95b865d1f6c23470e8dc70a29de4078c12b24dbdf626f7e40299 = $this->env->getExtension("native_profiler");
        $__internal_644cda8bad9b95b865d1f6c23470e8dc70a29de4078c12b24dbdf626f7e40299->enter($__internal_644cda8bad9b95b865d1f6c23470e8dc70a29de4078c12b24dbdf626f7e40299_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_644cda8bad9b95b865d1f6c23470e8dc70a29de4078c12b24dbdf626f7e40299->leave($__internal_644cda8bad9b95b865d1f6c23470e8dc70a29de4078c12b24dbdf626f7e40299_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'search')) ?>*/
/* */

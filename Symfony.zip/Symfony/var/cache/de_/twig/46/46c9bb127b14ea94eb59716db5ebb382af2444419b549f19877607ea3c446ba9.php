<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_aa61a24b756e4fa0d1eba3a1fc14e9a79ac868aae1f73e08018de5bb1c99ffa8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c94cfda0c091da50c88bd7405b6e57b665f61dacf1a4f401652c13a34653105d = $this->env->getExtension("native_profiler");
        $__internal_c94cfda0c091da50c88bd7405b6e57b665f61dacf1a4f401652c13a34653105d->enter($__internal_c94cfda0c091da50c88bd7405b6e57b665f61dacf1a4f401652c13a34653105d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_c94cfda0c091da50c88bd7405b6e57b665f61dacf1a4f401652c13a34653105d->leave($__internal_c94cfda0c091da50c88bd7405b6e57b665f61dacf1a4f401652c13a34653105d_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */

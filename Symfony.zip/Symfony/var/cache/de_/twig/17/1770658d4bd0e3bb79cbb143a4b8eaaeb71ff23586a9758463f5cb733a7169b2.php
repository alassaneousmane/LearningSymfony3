<?php

/* @Twig/Exception/exception.json.twig */
class __TwigTemplate_780896af88f0eff46057eb2556e0fa7732ff66941c8649adfa7c34e42ae91c1b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f16de6c43d23231dc2a38fc397ea0833f70c432607fd2351dd826d9117a72c14 = $this->env->getExtension("native_profiler");
        $__internal_f16de6c43d23231dc2a38fc397ea0833f70c432607fd2351dd826d9117a72c14->enter($__internal_f16de6c43d23231dc2a38fc397ea0833f70c432607fd2351dd826d9117a72c14_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "exception" => $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "toarray", array()))));
        echo "
";
        
        $__internal_f16de6c43d23231dc2a38fc397ea0833f70c432607fd2351dd826d9117a72c14->leave($__internal_f16de6c43d23231dc2a38fc397ea0833f70c432607fd2351dd826d9117a72c14_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}*/
/* */

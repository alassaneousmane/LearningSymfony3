<?php

/* @Twig/Exception/error.json.twig */
class __TwigTemplate_a66d45f4e37813720bd17195e3a489258dbba7d924c040eed3214268d4158685 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_51077cecb7959eb939bfaa38c92faa457924cf953f0f147ac37a107b707454a6 = $this->env->getExtension("native_profiler");
        $__internal_51077cecb7959eb939bfaa38c92faa457924cf953f0f147ac37a107b707454a6->enter($__internal_51077cecb7959eb939bfaa38c92faa457924cf953f0f147ac37a107b707454a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_51077cecb7959eb939bfaa38c92faa457924cf953f0f147ac37a107b707454a6->leave($__internal_51077cecb7959eb939bfaa38c92faa457924cf953f0f147ac37a107b707454a6_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}*/
/* */

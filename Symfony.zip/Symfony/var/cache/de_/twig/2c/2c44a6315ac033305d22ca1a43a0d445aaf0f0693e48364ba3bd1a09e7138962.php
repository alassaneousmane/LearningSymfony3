<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_f459cfbe9259c3b989dd7da591e8eea0e13109edf9a81a95c749cc4dd149bdb8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a4748c44bb6b134995ebafd6939ceba785a266c9b055e4034b53d816e1b57f21 = $this->env->getExtension("native_profiler");
        $__internal_a4748c44bb6b134995ebafd6939ceba785a266c9b055e4034b53d816e1b57f21->enter($__internal_a4748c44bb6b134995ebafd6939ceba785a266c9b055e4034b53d816e1b57f21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_a4748c44bb6b134995ebafd6939ceba785a266c9b055e4034b53d816e1b57f21->leave($__internal_a4748c44bb6b134995ebafd6939ceba785a266c9b055e4034b53d816e1b57f21_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'number')) ?>*/
/* */

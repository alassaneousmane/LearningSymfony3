<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_9799288140dc03c836d09149a7112883bc4382f20c32651e45691a7f6c6125ea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b563461542565481bc9cdaa3cb93e71ca46bb1d91537f228305c5b61c5151646 = $this->env->getExtension("native_profiler");
        $__internal_b563461542565481bc9cdaa3cb93e71ca46bb1d91537f228305c5b61c5151646->enter($__internal_b563461542565481bc9cdaa3cb93e71ca46bb1d91537f228305c5b61c5151646_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_b563461542565481bc9cdaa3cb93e71ca46bb1d91537f228305c5b61c5151646->leave($__internal_b563461542565481bc9cdaa3cb93e71ca46bb1d91537f228305c5b61c5151646_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/* <?php foreach ($form as $child): ?>*/
/*     <?php echo $view['form']->widget($child) ?>*/
/*     <?php echo $view['form']->label($child, null, array('translation_domain' => $choice_translation_domain)) ?>*/
/* <?php endforeach ?>*/
/* </div>*/
/* */

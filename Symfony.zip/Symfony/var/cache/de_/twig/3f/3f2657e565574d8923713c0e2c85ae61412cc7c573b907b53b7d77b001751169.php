<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_a965df2a8d2c5318c1c380431a4367a03b7bbc2cf9951fe029b936fdab7e49d9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_82fc80313acb149e5f1b2e781eaea5a994daccabfed945e6643186484198d731 = $this->env->getExtension("native_profiler");
        $__internal_82fc80313acb149e5f1b2e781eaea5a994daccabfed945e6643186484198d731->enter($__internal_82fc80313acb149e5f1b2e781eaea5a994daccabfed945e6643186484198d731_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
";
        
        $__internal_82fc80313acb149e5f1b2e781eaea5a994daccabfed945e6643186484198d731->leave($__internal_82fc80313acb149e5f1b2e781eaea5a994daccabfed945e6643186484198d731_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <table <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*     <?php if (!$form->parent && $errors): ?>*/
/*     <tr>*/
/*         <td colspan="2">*/
/*             <?php echo $view['form']->errors($form) ?>*/
/*         </td>*/
/*     </tr>*/
/*     <?php endif ?>*/
/*     <?php echo $view['form']->block($form, 'form_rows') ?>*/
/*     <?php echo $view['form']->rest($form) ?>*/
/* </table>*/
/* */

<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_140f91c948b786f243050b1c947f38294ff57b07a4144a5035c713102d9ff846 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4354aa5ba4675e5c7b846554a046e34c971b975725ed4e16783135907e90db5d = $this->env->getExtension("native_profiler");
        $__internal_4354aa5ba4675e5c7b846554a046e34c971b975725ed4e16783135907e90db5d->enter($__internal_4354aa5ba4675e5c7b846554a046e34c971b975725ed4e16783135907e90db5d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_4354aa5ba4675e5c7b846554a046e34c971b975725ed4e16783135907e90db5d->leave($__internal_4354aa5ba4675e5c7b846554a046e34c971b975725ed4e16783135907e90db5d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */

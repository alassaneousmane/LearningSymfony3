<?php

/* @Twig/Exception/exception.rdf.twig */
class __TwigTemplate_cb9f1ef8835ba5bae287006e355f77e8baab0955b0aa44f224abd90ec4533b07 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0fc991027b741261c251fb879bd5b9b716277be85bf9143169d3fd8fbbc72de3 = $this->env->getExtension("native_profiler");
        $__internal_0fc991027b741261c251fb879bd5b9b716277be85bf9143169d3fd8fbbc72de3->enter($__internal_0fc991027b741261c251fb879bd5b9b716277be85bf9143169d3fd8fbbc72de3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "@Twig/Exception/exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_0fc991027b741261c251fb879bd5b9b716277be85bf9143169d3fd8fbbc72de3->leave($__internal_0fc991027b741261c251fb879bd5b9b716277be85bf9143169d3fd8fbbc72de3_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */

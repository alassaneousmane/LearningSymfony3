<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_83df4edd983b379e9b587fb6ffa237ffdfabd160c53a41c1156fb1bc6d57236d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_603370edd590b4a50e36f4e4d601ae453e2b6e876dd6585b2134ff09617a2125 = $this->env->getExtension("native_profiler");
        $__internal_603370edd590b4a50e36f4e4d601ae453e2b6e876dd6585b2134ff09617a2125->enter($__internal_603370edd590b4a50e36f4e4d601ae453e2b6e876dd6585b2134ff09617a2125_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_603370edd590b4a50e36f4e4d601ae453e2b6e876dd6585b2134ff09617a2125->leave($__internal_603370edd590b4a50e36f4e4d601ae453e2b6e876dd6585b2134ff09617a2125_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (!isset($render_rest) || $render_rest): ?>*/
/* <?php echo $view['form']->rest($form) ?>*/
/* <?php endif ?>*/
/* </form>*/
/* */

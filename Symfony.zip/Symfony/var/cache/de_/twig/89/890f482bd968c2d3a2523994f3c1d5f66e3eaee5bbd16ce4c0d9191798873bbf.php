<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_e20701bafcd8de1a1a3288ea01a0d90fdbc5fa943e0374d35dea8bac3f7a4596 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b9e2554c3f2e6a922f8b3c0ed7833d2bf6d1b3991743ebf934d1d1d53b3bd887 = $this->env->getExtension("native_profiler");
        $__internal_b9e2554c3f2e6a922f8b3c0ed7833d2bf6d1b3991743ebf934d1d1d53b3bd887->enter($__internal_b9e2554c3f2e6a922f8b3c0ed7833d2bf6d1b3991743ebf934d1d1d53b3bd887_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_b9e2554c3f2e6a922f8b3c0ed7833d2bf6d1b3991743ebf934d1d1d53b3bd887->leave($__internal_b9e2554c3f2e6a922f8b3c0ed7833d2bf6d1b3991743ebf934d1d1d53b3bd887_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($expanded): ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_expanded') ?>*/
/* <?php else: ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_collapsed') ?>*/
/* <?php endif ?>*/
/* */

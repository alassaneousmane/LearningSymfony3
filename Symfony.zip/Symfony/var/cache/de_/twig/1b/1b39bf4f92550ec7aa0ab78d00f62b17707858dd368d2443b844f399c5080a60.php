<?php

/* @Framework/Form/button_widget.html.php */
class __TwigTemplate_5b529abff6d5c9cf8785dbe496cd801b8ea8edd052d1324a8a32a89caf7d2985 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9e7cda7d747efc3e1035b8fff200ba19584c45ccf57fc92b7d2e4740d5406e20 = $this->env->getExtension("native_profiler");
        $__internal_9e7cda7d747efc3e1035b8fff200ba19584c45ccf57fc92b7d2e4740d5406e20->enter($__internal_9e7cda7d747efc3e1035b8fff200ba19584c45ccf57fc92b7d2e4740d5406e20_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        // line 1
        echo "<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
";
        
        $__internal_9e7cda7d747efc3e1035b8fff200ba19584c45ccf57fc92b7d2e4740d5406e20->leave($__internal_9e7cda7d747efc3e1035b8fff200ba19584c45ccf57fc92b7d2e4740d5406e20_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (!$label) { $label = isset($label_format)*/
/*     ? strtr($label_format, array('%name%' => $name, '%id%' => $id))*/
/*     : $view['form']->humanize($name); } ?>*/
/* <button type="<?php echo isset($type) ? $view->escape($type) : 'button' ?>" <?php echo $view['form']->block($form, 'button_attributes') ?>><?php echo $view->escape(false !== $translation_domain ? $view['translator']->trans($label, array(), $translation_domain) : $label) ?></button>*/
/* */

<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_ef46af3776e56b3e9b6cd6f8d07838eeba21562531553316f329718818662ee3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6c12079dbb3a43ffd5a40977cc01b7ecdca259544a0909238ca26749c7cc2cbd = $this->env->getExtension("native_profiler");
        $__internal_6c12079dbb3a43ffd5a40977cc01b7ecdca259544a0909238ca26749c7cc2cbd->enter($__internal_6c12079dbb3a43ffd5a40977cc01b7ecdca259544a0909238ca26749c7cc2cbd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_6c12079dbb3a43ffd5a40977cc01b7ecdca259544a0909238ca26749c7cc2cbd->leave($__internal_6c12079dbb3a43ffd5a40977cc01b7ecdca259544a0909238ca26749c7cc2cbd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'range'));*/
/* */

<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_e8e50e0e214aa7497a094daabc87bce5608da28cb3ec3703a0dd9f497a912ac6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a6b714c5fe1e2d9ca5258e762bfe489f6e12ca2df9dcbef79cc50a0c28615c32 = $this->env->getExtension("native_profiler");
        $__internal_a6b714c5fe1e2d9ca5258e762bfe489f6e12ca2df9dcbef79cc50a0c28615c32->enter($__internal_a6b714c5fe1e2d9ca5258e762bfe489f6e12ca2df9dcbef79cc50a0c28615c32_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_a6b714c5fe1e2d9ca5258e762bfe489f6e12ca2df9dcbef79cc50a0c28615c32->leave($__internal_a6b714c5fe1e2d9ca5258e762bfe489f6e12ca2df9dcbef79cc50a0c28615c32_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="<?php echo isset($type) ? $view->escape($type) : 'text' ?>" <?php echo $view['form']->block($form, 'widget_attributes') ?><?php if (!empty($value) || is_numeric($value)): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?> />*/
/* */

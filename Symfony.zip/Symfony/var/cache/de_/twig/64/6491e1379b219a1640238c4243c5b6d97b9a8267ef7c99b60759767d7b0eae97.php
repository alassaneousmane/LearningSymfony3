<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_873943a179a88eabd73fa5c3a6c5701757be2278ef52e677a4b304ff1d2e5d49 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b3683e0bf11bdcee6a7745433a710ed43cc6b74640bf2eeb48c26c8a0772d5c8 = $this->env->getExtension("native_profiler");
        $__internal_b3683e0bf11bdcee6a7745433a710ed43cc6b74640bf2eeb48c26c8a0772d5c8->enter($__internal_b3683e0bf11bdcee6a7745433a710ed43cc6b74640bf2eeb48c26c8a0772d5c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_b3683e0bf11bdcee6a7745433a710ed43cc6b74640bf2eeb48c26c8a0772d5c8->leave($__internal_b3683e0bf11bdcee6a7745433a710ed43cc6b74640bf2eeb48c26c8a0772d5c8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->start($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* <?php echo $view['form']->end($form) ?>*/
/* */

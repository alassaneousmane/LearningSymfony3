<?php

/* @Framework/Form/money_widget.html.php */
class __TwigTemplate_e0dcd9355a601b41c1f68b92b9bee581015ad1deeae552ddbfd198165f69ad29 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f4153bf0f033d2ce33c4aef2840ac3bab67b543a86448e07b80a6ff13113caa0 = $this->env->getExtension("native_profiler");
        $__internal_f4153bf0f033d2ce33c4aef2840ac3bab67b543a86448e07b80a6ff13113caa0->enter($__internal_f4153bf0f033d2ce33c4aef2840ac3bab67b543a86448e07b80a6ff13113caa0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        // line 1
        echo "<?php echo str_replace('";
        echo twig_escape_filter($this->env, (isset($context["widget"]) ? $context["widget"] : $this->getContext($context, "widget")), "html", null, true);
        echo "', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
";
        
        $__internal_f4153bf0f033d2ce33c4aef2840ac3bab67b543a86448e07b80a6ff13113caa0->leave($__internal_f4153bf0f033d2ce33c4aef2840ac3bab67b543a86448e07b80a6ff13113caa0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/money_widget.html.php";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo str_replace('{{ widget }}', $view['form']->block($form, 'form_widget_simple'), $money_pattern) ?>*/
/* */

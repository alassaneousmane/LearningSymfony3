<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_22f7bd783f9415f66f4ee8de0de250148cc9a153aca406c9f8e5241f411f76ac extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_354e8e97a609e88015299ef789eed25bdc488b0a82782e2f533406e5a7c7e876 = $this->env->getExtension("native_profiler");
        $__internal_354e8e97a609e88015299ef789eed25bdc488b0a82782e2f533406e5a7c7e876->enter($__internal_354e8e97a609e88015299ef789eed25bdc488b0a82782e2f533406e5a7c7e876_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_354e8e97a609e88015299ef789eed25bdc488b0a82782e2f533406e5a7c7e876->leave($__internal_354e8e97a609e88015299ef789eed25bdc488b0a82782e2f533406e5a7c7e876_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'reset')) ?>*/
/* */

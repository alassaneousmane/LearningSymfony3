<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_ca9468bbfe1fcca72900a65c92618789b71cd441da5c7237c515ea59f5430f33 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c99dfe15c47be9eaf0d48ee2d38180da38864f70d23f70778663b45d6a0a5f68 = $this->env->getExtension("native_profiler");
        $__internal_c99dfe15c47be9eaf0d48ee2d38180da38864f70d23f70778663b45d6a0a5f68->enter($__internal_c99dfe15c47be9eaf0d48ee2d38180da38864f70d23f70778663b45d6a0a5f68_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.atom.twig", 1)->display($context);
        
        $__internal_c99dfe15c47be9eaf0d48ee2d38180da38864f70d23f70778663b45d6a0a5f68->leave($__internal_c99dfe15c47be9eaf0d48ee2d38180da38864f70d23f70778663b45d6a0a5f68_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */

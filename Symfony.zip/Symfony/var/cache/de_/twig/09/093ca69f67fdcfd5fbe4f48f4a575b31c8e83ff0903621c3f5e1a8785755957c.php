<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_34dd1d31f48ddeeba720a6a576f24a79f19e8bcfafd0125e138ad33ad842f8ea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_315829528e3d0d7fef47bd908b58c65c3667a61ec10ded0ecae12a72d6904757 = $this->env->getExtension("native_profiler");
        $__internal_315829528e3d0d7fef47bd908b58c65c3667a61ec10ded0ecae12a72d6904757->enter($__internal_315829528e3d0d7fef47bd908b58c65c3667a61ec10ded0ecae12a72d6904757_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_315829528e3d0d7fef47bd908b58c65c3667a61ec10ded0ecae12a72d6904757->leave($__internal_315829528e3d0d7fef47bd908b58c65c3667a61ec10ded0ecae12a72d6904757_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php foreach ($form as $child): ?>*/
/*     <?php if (!$child->isRendered()): ?>*/
/*         <?php echo $view['form']->row($child) ?>*/
/*     <?php endif; ?>*/
/* <?php endforeach; ?>*/
/* */

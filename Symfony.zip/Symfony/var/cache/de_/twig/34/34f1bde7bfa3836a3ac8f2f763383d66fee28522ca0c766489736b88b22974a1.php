<?php

/* base.html.twig */
class __TwigTemplate_03e9f4aee4e4c127df2569e61d7ac515e2eb5c2cd693243c7fef393752b80198 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_337e908526de8327474991871594331d35a1a19465f16ef6e2870f0b18a4c420 = $this->env->getExtension("native_profiler");
        $__internal_337e908526de8327474991871594331d35a1a19465f16ef6e2870f0b18a4c420->enter($__internal_337e908526de8327474991871594331d35a1a19465f16ef6e2870f0b18a4c420_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_337e908526de8327474991871594331d35a1a19465f16ef6e2870f0b18a4c420->leave($__internal_337e908526de8327474991871594331d35a1a19465f16ef6e2870f0b18a4c420_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_7fb2ab69563106fbc239778ca94ec12a5a51063628f25c5328f7e35be8ff8d56 = $this->env->getExtension("native_profiler");
        $__internal_7fb2ab69563106fbc239778ca94ec12a5a51063628f25c5328f7e35be8ff8d56->enter($__internal_7fb2ab69563106fbc239778ca94ec12a5a51063628f25c5328f7e35be8ff8d56_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_7fb2ab69563106fbc239778ca94ec12a5a51063628f25c5328f7e35be8ff8d56->leave($__internal_7fb2ab69563106fbc239778ca94ec12a5a51063628f25c5328f7e35be8ff8d56_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_1fa96dec0e3e7fe912e13a7afa7215f129a4f6ffef06130d1ee714f84d4702b3 = $this->env->getExtension("native_profiler");
        $__internal_1fa96dec0e3e7fe912e13a7afa7215f129a4f6ffef06130d1ee714f84d4702b3->enter($__internal_1fa96dec0e3e7fe912e13a7afa7215f129a4f6ffef06130d1ee714f84d4702b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_1fa96dec0e3e7fe912e13a7afa7215f129a4f6ffef06130d1ee714f84d4702b3->leave($__internal_1fa96dec0e3e7fe912e13a7afa7215f129a4f6ffef06130d1ee714f84d4702b3_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_dc4f7876dd85fada18e7aa3de23050a5c48748c97247e1bb6bdcddbada746199 = $this->env->getExtension("native_profiler");
        $__internal_dc4f7876dd85fada18e7aa3de23050a5c48748c97247e1bb6bdcddbada746199->enter($__internal_dc4f7876dd85fada18e7aa3de23050a5c48748c97247e1bb6bdcddbada746199_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_dc4f7876dd85fada18e7aa3de23050a5c48748c97247e1bb6bdcddbada746199->leave($__internal_dc4f7876dd85fada18e7aa3de23050a5c48748c97247e1bb6bdcddbada746199_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_c7f0a5edba6e31f660cb37a37e4763a8696aec9f4238894e0fdadbe8237cd696 = $this->env->getExtension("native_profiler");
        $__internal_c7f0a5edba6e31f660cb37a37e4763a8696aec9f4238894e0fdadbe8237cd696->enter($__internal_c7f0a5edba6e31f660cb37a37e4763a8696aec9f4238894e0fdadbe8237cd696_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_c7f0a5edba6e31f660cb37a37e4763a8696aec9f4238894e0fdadbe8237cd696->leave($__internal_c7f0a5edba6e31f660cb37a37e4763a8696aec9f4238894e0fdadbe8237cd696_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Welcome!{% endblock %}</title>*/
/*         {% block stylesheets %}{% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/*     <body>*/
/*         {% block body %}{% endblock %}*/
/*         {% block javascripts %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */

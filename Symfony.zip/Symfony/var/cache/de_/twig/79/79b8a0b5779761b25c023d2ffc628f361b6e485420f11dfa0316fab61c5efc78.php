<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_20c4519e08473ba559fc81a84e2fd2b1a43df11b7b1245bd93918b24c17c56c0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cf57a2780f3f0c29d11e73067845889c299b1ee551a67dbe0fff437a6d3f359d = $this->env->getExtension("native_profiler");
        $__internal_cf57a2780f3f0c29d11e73067845889c299b1ee551a67dbe0fff437a6d3f359d->enter($__internal_cf57a2780f3f0c29d11e73067845889c299b1ee551a67dbe0fff437a6d3f359d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_cf57a2780f3f0c29d11e73067845889c299b1ee551a67dbe0fff437a6d3f359d->leave($__internal_cf57a2780f3f0c29d11e73067845889c299b1ee551a67dbe0fff437a6d3f359d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td>*/
/*         <?php echo $view['form']->label($form) ?>*/
/*     </td>*/
/*     <td>*/
/*         <?php echo $view['form']->errors($form) ?>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */

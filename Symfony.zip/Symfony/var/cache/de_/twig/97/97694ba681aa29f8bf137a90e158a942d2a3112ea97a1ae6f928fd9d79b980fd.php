<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_0e8195cc082f9dec0cc521237001505ff3bfe8b4dea46883ec6a414a8b6ed862 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e98d000fea49b22982e16572f3eba87041599a605c4ed2aee1d5f41fe1532fdb = $this->env->getExtension("native_profiler");
        $__internal_e98d000fea49b22982e16572f3eba87041599a605c4ed2aee1d5f41fe1532fdb->enter($__internal_e98d000fea49b22982e16572f3eba87041599a605c4ed2aee1d5f41fe1532fdb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_e98d000fea49b22982e16572f3eba87041599a605c4ed2aee1d5f41fe1532fdb->leave($__internal_e98d000fea49b22982e16572f3eba87041599a605c4ed2aee1d5f41fe1532fdb_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */

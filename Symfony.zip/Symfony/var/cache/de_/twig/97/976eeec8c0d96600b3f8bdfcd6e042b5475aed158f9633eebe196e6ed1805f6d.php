<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_a53e411dc4dacc2c877bd293d0d2182e1d4ef142de1b433cee118a854e21e40e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a1cb88ce8b50c68f76a0f323936e116e8c202ab41b96b4e4162cee7d7420cc80 = $this->env->getExtension("native_profiler");
        $__internal_a1cb88ce8b50c68f76a0f323936e116e8c202ab41b96b4e4162cee7d7420cc80->enter($__internal_a1cb88ce8b50c68f76a0f323936e116e8c202ab41b96b4e4162cee7d7420cc80_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_a1cb88ce8b50c68f76a0f323936e116e8c202ab41b96b4e4162cee7d7420cc80->leave($__internal_a1cb88ce8b50c68f76a0f323936e116e8c202ab41b96b4e4162cee7d7420cc80_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="checkbox"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     <?php if (strlen($value) > 0): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?>*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */

<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_1ceaca6bd2cdeb71c2a5ec0c728b63efde7de39988445b54889b58c4e286a676 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5e594520ea5abb5fe23b16a15424bbce4fe8295d173f148d33196ba425456057 = $this->env->getExtension("native_profiler");
        $__internal_5e594520ea5abb5fe23b16a15424bbce4fe8295d173f148d33196ba425456057->enter($__internal_5e594520ea5abb5fe23b16a15424bbce4fe8295d173f148d33196ba425456057_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.rdf.twig", 1)->display($context);
        
        $__internal_5e594520ea5abb5fe23b16a15424bbce4fe8295d173f148d33196ba425456057->leave($__internal_5e594520ea5abb5fe23b16a15424bbce4fe8295d173f148d33196ba425456057_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */

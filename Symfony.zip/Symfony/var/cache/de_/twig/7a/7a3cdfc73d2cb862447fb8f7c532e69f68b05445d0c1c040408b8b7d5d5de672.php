<?php

/* OCPlatformBundle:Test:index.html.twig */
class __TwigTemplate_80989867141d499342f8d423c3ced3387c5537583ce01d6370e30ed6dcd53150 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d4e1e4ed848685fee3cdd40780c89320b66d3249a20eefe26bbaa6ea9cec30a1 = $this->env->getExtension("native_profiler");
        $__internal_d4e1e4ed848685fee3cdd40780c89320b66d3249a20eefe26bbaa6ea9cec30a1->enter($__internal_d4e1e4ed848685fee3cdd40780c89320b66d3249a20eefe26bbaa6ea9cec30a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Test:index.html.twig"));

        // line 1
        echo "

<!DOCTYPE html>
<html>
  <head>
    <title>Bienvenue sur ma première page avec OpenClassrooms !</title>
  </head>
  <body>
    <h1>ByeBye World !</h1>
    <hr/>

    <p>
      Le ByeBye World est un grand classique en programmation.
      Il signifie énormément, car cela veut dire que vous avez
      réussi à exécuter le programme pour accomplir une tâche simple :
      afficher ce hello world !
    </p>
  </body>
</html>
";
        
        $__internal_d4e1e4ed848685fee3cdd40780c89320b66d3249a20eefe26bbaa6ea9cec30a1->leave($__internal_d4e1e4ed848685fee3cdd40780c89320b66d3249a20eefe26bbaa6ea9cec30a1_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Test:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* */
/* */
/* <!DOCTYPE html>*/
/* <html>*/
/*   <head>*/
/*     <title>Bienvenue sur ma première page avec OpenClassrooms !</title>*/
/*   </head>*/
/*   <body>*/
/*     <h1>ByeBye World !</h1>*/
/*     <hr/>*/
/* */
/*     <p>*/
/*       Le ByeBye World est un grand classique en programmation.*/
/*       Il signifie énormément, car cela veut dire que vous avez*/
/*       réussi à exécuter le programme pour accomplir une tâche simple :*/
/*       afficher ce hello world !*/
/*     </p>*/
/*   </body>*/
/* </html>*/
/* */

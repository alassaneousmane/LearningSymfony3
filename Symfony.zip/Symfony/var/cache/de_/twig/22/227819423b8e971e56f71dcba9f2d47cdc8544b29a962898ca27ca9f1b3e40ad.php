<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_c996e9a4a5ad6fc14a39f48938c63b5d7f1970fbff1c49086e31f6b530506bb7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5443727bbb7fffde23adac3918b049d38cbfd8eb8e5d84dea2cf94573fce7549 = $this->env->getExtension("native_profiler");
        $__internal_5443727bbb7fffde23adac3918b049d38cbfd8eb8e5d84dea2cf94573fce7549->enter($__internal_5443727bbb7fffde23adac3918b049d38cbfd8eb8e5d84dea2cf94573fce7549_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_5443727bbb7fffde23adac3918b049d38cbfd8eb8e5d84dea2cf94573fce7549->leave($__internal_5443727bbb7fffde23adac3918b049d38cbfd8eb8e5d84dea2cf94573fce7549_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'hidden')) ?>*/
/* */

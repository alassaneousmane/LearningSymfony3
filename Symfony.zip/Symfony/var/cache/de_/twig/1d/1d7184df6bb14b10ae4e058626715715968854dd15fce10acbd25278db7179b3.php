<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_8510d17977e305f56ea004b6c81d0fefe90b29fb94dbbe88c539b2a11efad724 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cd89eee6564cf7fa4a6a81b4c0ef196aa22fc64018e68c160b3b8b947d8c041c = $this->env->getExtension("native_profiler");
        $__internal_cd89eee6564cf7fa4a6a81b4c0ef196aa22fc64018e68c160b3b8b947d8c041c->enter($__internal_cd89eee6564cf7fa4a6a81b4c0ef196aa22fc64018e68c160b3b8b947d8c041c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_cd89eee6564cf7fa4a6a81b4c0ef196aa22fc64018e68c160b3b8b947d8c041c->leave($__internal_cd89eee6564cf7fa4a6a81b4c0ef196aa22fc64018e68c160b3b8b947d8c041c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}

<?php

/* TwigBundle:Exception:error404.html.twig */
class __TwigTemplate_931692d90750c8cfe799a62f8a4af1dd5d483b46ec86356270477ee8819bca35 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b2f76e37e0c26b865de2004688a62644246c2e1aff1f81926d7978fa09d19fea = $this->env->getExtension("native_profiler");
        $__internal_b2f76e37e0c26b865de2004688a62644246c2e1aff1f81926d7978fa09d19fea->enter($__internal_b2f76e37e0c26b865de2004688a62644246c2e1aff1f81926d7978fa09d19fea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error404.html.twig"));

        
        $__internal_b2f76e37e0c26b865de2004688a62644246c2e1aff1f81926d7978fa09d19fea->leave($__internal_b2f76e37e0c26b865de2004688a62644246c2e1aff1f81926d7978fa09d19fea_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error404.html.twig";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}

<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_171e0eba44fce2d3906f6e1c419639658ec6833905aa06671f81bd743fafa8ae extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_55f794a5e712f4d1982ea933e0c59d20b1a5173e026cdb39cf9bd3c87b0a4882 = $this->env->getExtension("native_profiler");
        $__internal_55f794a5e712f4d1982ea933e0c59d20b1a5173e026cdb39cf9bd3c87b0a4882->enter($__internal_55f794a5e712f4d1982ea933e0c59d20b1a5173e026cdb39cf9bd3c87b0a4882_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_55f794a5e712f4d1982ea933e0c59d20b1a5173e026cdb39cf9bd3c87b0a4882->leave($__internal_55f794a5e712f4d1982ea933e0c59d20b1a5173e026cdb39cf9bd3c87b0a4882_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->widget($form) ?>*/
/* */

<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_909fb9c6f002975b6fa5a1c844b531db308bb533d861e438971866b4505d55e7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0b559f7f7256400a9f5e9fbe5f6cd9420368b662b76c1110dc8f8ee07c87aed0 = $this->env->getExtension("native_profiler");
        $__internal_0b559f7f7256400a9f5e9fbe5f6cd9420368b662b76c1110dc8f8ee07c87aed0->enter($__internal_0b559f7f7256400a9f5e9fbe5f6cd9420368b662b76c1110dc8f8ee07c87aed0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_0b559f7f7256400a9f5e9fbe5f6cd9420368b662b76c1110dc8f8ee07c87aed0->leave($__internal_0b559f7f7256400a9f5e9fbe5f6cd9420368b662b76c1110dc8f8ee07c87aed0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'password')) ?>*/
/* */

<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_dccde38f2293b0427b8ef192f5cbd817b724d930d3843115745b9c8232644ad7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fc6fd8dca99a6bacc8376765abf3f73f518ed52368b0220ad585befaff4eb66a = $this->env->getExtension("native_profiler");
        $__internal_fc6fd8dca99a6bacc8376765abf3f73f518ed52368b0220ad585befaff4eb66a->enter($__internal_fc6fd8dca99a6bacc8376765abf3f73f518ed52368b0220ad585befaff4eb66a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_fc6fd8dca99a6bacc8376765abf3f73f518ed52368b0220ad585befaff4eb66a->leave($__internal_fc6fd8dca99a6bacc8376765abf3f73f518ed52368b0220ad585befaff4eb66a_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_0a0f187e2d1edb6215b686c30f01066df1ac261235e60478b4f0bf513be469f8 = $this->env->getExtension("native_profiler");
        $__internal_0a0f187e2d1edb6215b686c30f01066df1ac261235e60478b4f0bf513be469f8->enter($__internal_0a0f187e2d1edb6215b686c30f01066df1ac261235e60478b4f0bf513be469f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_0a0f187e2d1edb6215b686c30f01066df1ac261235e60478b4f0bf513be469f8->leave($__internal_0a0f187e2d1edb6215b686c30f01066df1ac261235e60478b4f0bf513be469f8_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */

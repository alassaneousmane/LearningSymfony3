<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_94e8c9dbc3c0a595a5655cc0100ad46e4e86cf3cd541f3910c0b65e8dca4ab5e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7646a96d4e499464759b86b77ead9c37815158ff968ebc77e21e99cd83cee4a1 = $this->env->getExtension("native_profiler");
        $__internal_7646a96d4e499464759b86b77ead9c37815158ff968ebc77e21e99cd83cee4a1->enter($__internal_7646a96d4e499464759b86b77ead9c37815158ff968ebc77e21e99cd83cee4a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_7646a96d4e499464759b86b77ead9c37815158ff968ebc77e21e99cd83cee4a1->leave($__internal_7646a96d4e499464759b86b77ead9c37815158ff968ebc77e21e99cd83cee4a1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'choice_widget_options') ?>*/
/* */

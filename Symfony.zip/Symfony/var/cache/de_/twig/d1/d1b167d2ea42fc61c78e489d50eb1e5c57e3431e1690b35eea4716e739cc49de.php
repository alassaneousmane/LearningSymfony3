<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_97eed28c91dfb1874fa283fecb7152516f3cc32ea89dbc7c5877d0feb1fce80a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_50143c1f6467938b195798a553a084cf5608d1059be011aa6303eb7cf2302188 = $this->env->getExtension("native_profiler");
        $__internal_50143c1f6467938b195798a553a084cf5608d1059be011aa6303eb7cf2302188->enter($__internal_50143c1f6467938b195798a553a084cf5608d1059be011aa6303eb7cf2302188_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_50143c1f6467938b195798a553a084cf5608d1059be011aa6303eb7cf2302188->leave($__internal_50143c1f6467938b195798a553a084cf5608d1059be011aa6303eb7cf2302188_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_53a3c7b8615664e6454d5476393850ef48f555ef997b7d42c8e4918e25a032df = $this->env->getExtension("native_profiler");
        $__internal_53a3c7b8615664e6454d5476393850ef48f555ef997b7d42c8e4918e25a032df->enter($__internal_53a3c7b8615664e6454d5476393850ef48f555ef997b7d42c8e4918e25a032df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_53a3c7b8615664e6454d5476393850ef48f555ef997b7d42c8e4918e25a032df->leave($__internal_53a3c7b8615664e6454d5476393850ef48f555ef997b7d42c8e4918e25a032df_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */

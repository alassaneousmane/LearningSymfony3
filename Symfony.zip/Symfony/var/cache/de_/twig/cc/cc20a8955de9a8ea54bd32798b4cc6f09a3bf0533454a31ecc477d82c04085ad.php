<?php

/* @Twig/Exception/error.css.twig */
class __TwigTemplate_5ebbf0b9bd0f6d1663eb15c1d1a4d6eae245110017a0fb44d05ddc5dc293aecf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7c88d0ba802428d449036bc4ea585e6dec7bb0b2cfe24b9083980fef6abc9655 = $this->env->getExtension("native_profiler");
        $__internal_7c88d0ba802428d449036bc4ea585e6dec7bb0b2cfe24b9083980fef6abc9655->enter($__internal_7c88d0ba802428d449036bc4ea585e6dec7bb0b2cfe24b9083980fef6abc9655_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_7c88d0ba802428d449036bc4ea585e6dec7bb0b2cfe24b9083980fef6abc9655->leave($__internal_7c88d0ba802428d449036bc4ea585e6dec7bb0b2cfe24b9083980fef6abc9655_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {{ status_code }} {{ status_text }}*/
/* */
/* *//* */
/* */

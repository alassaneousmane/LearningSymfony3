<?php

/* @Twig/Exception/exception.atom.twig */
class __TwigTemplate_3ba7f151b91fea860291c07230ae8c24a5235453f920659bb6f30e1c7edfb869 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_95dede8b2798532dae976168e85e948a61a62408cf20d9ea55a8a55e39351985 = $this->env->getExtension("native_profiler");
        $__internal_95dede8b2798532dae976168e85e948a61a62408cf20d9ea55a8a55e39351985->enter($__internal_95dede8b2798532dae976168e85e948a61a62408cf20d9ea55a8a55e39351985_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "@Twig/Exception/exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_95dede8b2798532dae976168e85e948a61a62408cf20d9ea55a8a55e39351985->leave($__internal_95dede8b2798532dae976168e85e948a61a62408cf20d9ea55a8a55e39351985_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */

<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_1de28971f7f7ce58dd73e914dda4bdc6b9f02a6d5d7895a7758442ac0c9b02e9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6d118ae731b92f2e8a22130148edd98dd1ebb4f43a17035e4d2063a5bd1463d1 = $this->env->getExtension("native_profiler");
        $__internal_6d118ae731b92f2e8a22130148edd98dd1ebb4f43a17035e4d2063a5bd1463d1->enter($__internal_6d118ae731b92f2e8a22130148edd98dd1ebb4f43a17035e4d2063a5bd1463d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_6d118ae731b92f2e8a22130148edd98dd1ebb4f43a17035e4d2063a5bd1463d1->leave($__internal_6d118ae731b92f2e8a22130148edd98dd1ebb4f43a17035e4d2063a5bd1463d1_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */

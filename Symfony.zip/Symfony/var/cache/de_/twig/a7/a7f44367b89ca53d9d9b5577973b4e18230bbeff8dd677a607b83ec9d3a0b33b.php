<?php

/* TwigBundle:Exception:error.json.twig */
class __TwigTemplate_067803966959801a1d0cddacefd58d070c9e48767275ea33a2a8506a7134d842 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8d454572185210ef65988dca27a7ce18850bfe85e5b572b2a8e2e5f9a6f984e8 = $this->env->getExtension("native_profiler");
        $__internal_8d454572185210ef65988dca27a7ce18850bfe85e5b572b2a8e2e5f9a6f984e8->enter($__internal_8d454572185210ef65988dca27a7ce18850bfe85e5b572b2a8e2e5f9a6f984e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_8d454572185210ef65988dca27a7ce18850bfe85e5b572b2a8e2e5f9a6f984e8->leave($__internal_8d454572185210ef65988dca27a7ce18850bfe85e5b572b2a8e2e5f9a6f984e8_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}*/
/* */

<?php

/* @Twig/Exception/error.xml.twig */
class __TwigTemplate_66a56c2809e0006be308369010120e25dd8c41706d80855051aee7ec06b5dd5a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_070fc8ba066850c5c63bd53634375121230c1f665c13860d94ac4c8233786132 = $this->env->getExtension("native_profiler");
        $__internal_070fc8ba066850c5c63bd53634375121230c1f665c13860d94ac4c8233786132->enter($__internal_070fc8ba066850c5c63bd53634375121230c1f665c13860d94ac4c8233786132_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.xml.twig"));

        // line 1
        echo "<?xml version=\"1.0\" encoding=\"";
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" ?>

<error code=\"";
        // line 3
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo "\" message=\"";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo "\" />
";
        
        $__internal_070fc8ba066850c5c63bd53634375121230c1f665c13860d94ac4c8233786132->leave($__internal_070fc8ba066850c5c63bd53634375121230c1f665c13860d94ac4c8233786132_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.xml.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 3,  22 => 1,);
    }
}
/* <?xml version="1.0" encoding="{{ _charset }}" ?>*/
/* */
/* <error code="{{ status_code }}" message="{{ status_text }}" />*/
/* */

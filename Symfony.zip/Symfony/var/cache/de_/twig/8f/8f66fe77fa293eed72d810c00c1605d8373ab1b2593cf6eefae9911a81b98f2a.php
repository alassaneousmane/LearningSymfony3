<?php

/* @OCPlatform/Advert/index.html.twig */
class __TwigTemplate_d241f356d54514132bedf396ac4fd889892997170a16039484eb5ae86a888b5a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e7560fe7711e4a06d629bf598d5c3b9c9a67cd242beb5093e431cd40592f05d1 = $this->env->getExtension("native_profiler");
        $__internal_e7560fe7711e4a06d629bf598d5c3b9c9a67cd242beb5093e431cd40592f05d1->enter($__internal_e7560fe7711e4a06d629bf598d5c3b9c9a67cd242beb5093e431cd40592f05d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@OCPlatform/Advert/index.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
  <head>
    <title>Annonce N° ";
        // line 4
        echo twig_escape_filter($this->env, strip_tags((isset($context["author"]) ? $context["author"] : $this->getContext($context, "author"))), "html", null, true);
        echo "!</title>
    <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css\">
    <style>
    p
    {
    color : blue;
    }
    </style>
  </head>
  <body>
    

    <p>
    <center>
 <div class=\"main-content\">
 <div class=\"jumbotron\">
       <h1> Hello Annonce N° ";
        // line 20
        echo twig_escape_filter($this->env, (isset($context["pageId"]) ? $context["pageId"] : $this->getContext($context, "pageId")), "html", null, true);
        echo " </h1> 
            </center>
    </p>
    <p> ";
        // line 24
        echo "           Il faut avoir au moins 12 ans pour regarder ce film
        ";
        // line 26
        echo "          Ok, bon film!
        ";
        // line 28
        echo "          Un peu vieux pour ce film non ?
        ";
        // line 30
        echo "        </p><p><strong>Boucle</strong>
        <ul>
        ";
        // line 33
        echo "          <li> ";
        echo " </li>
        ";
        // line 35
        echo "          <li>Pas d'utilisateur trouvé</li>
        ";
        // line 37
        echo "        </ul>
        </p>
        </div>
        </div>
    <footer> Responsable du site : <strong> ";
        // line 41
        echo twig_escape_filter($this->env, (isset($context["webmaster"]) ? $context["webmaster"] : $this->getContext($context, "webmaster")), "html", null, true);
        echo " </strong></footer>
     <script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>

    <script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js\"></script>
  </body>
</html>
";
        
        $__internal_e7560fe7711e4a06d629bf598d5c3b9c9a67cd242beb5093e431cd40592f05d1->leave($__internal_e7560fe7711e4a06d629bf598d5c3b9c9a67cd242beb5093e431cd40592f05d1_prof);

    }

    public function getTemplateName()
    {
        return "@OCPlatform/Advert/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 41,  72 => 37,  69 => 35,  65 => 33,  61 => 30,  58 => 28,  55 => 26,  52 => 24,  46 => 20,  27 => 4,  22 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*   <head>*/
/*     <title>Annonce N° {{ author|striptags  }}!</title>*/
/*     <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">*/
/*     <style>*/
/*     p*/
/*     {*/
/*     color : blue;*/
/*     }*/
/*     </style>*/
/*   </head>*/
/*   <body>*/
/*     */
/* */
/*     <p>*/
/*     <center>*/
/*  <div class="main-content">*/
/*  <div class="jumbotron">*/
/*        <h1> Hello Annonce N° {{ pageId  }} </h1> */
/*             </center>*/
/*     </p>*/
/*     <p> {# if member.age < 12 #}*/
/*            Il faut avoir au moins 12 ans pour regarder ce film*/
/*         {# elseif member.age < 18 #}*/
/*           Ok, bon film!*/
/*         {# else #}*/
/*           Un peu vieux pour ce film non ?*/
/*         {# endif #}*/
/*         </p><p><strong>Boucle</strong>*/
/*         <ul>*/
/*         {# for member in liste_members #}*/
/*           <li> {# member.pseudo #} </li>*/
/*         {# else #}*/
/*           <li>Pas d'utilisateur trouvé</li>*/
/*         {# endfor #}*/
/*         </ul>*/
/*         </p>*/
/*         </div>*/
/*         </div>*/
/*     <footer> Responsable du site : <strong> {{ webmaster }} </strong></footer>*/
/*      <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>*/
/* */
/*     <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>*/
/*   </body>*/
/* </html>*/
/* */

<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_19d9286a67002fea3a2cb390039fbbedc6cfb8d3b8641941bd04c40e660a147a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ec10b812cb5e7d58ded7996e89cfa545f1c9ca7a2f13ef4cf39116b53268a585 = $this->env->getExtension("native_profiler");
        $__internal_ec10b812cb5e7d58ded7996e89cfa545f1c9ca7a2f13ef4cf39116b53268a585->enter($__internal_ec10b812cb5e7d58ded7996e89cfa545f1c9ca7a2f13ef4cf39116b53268a585_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_ec10b812cb5e7d58ded7996e89cfa545f1c9ca7a2f13ef4cf39116b53268a585->leave($__internal_ec10b812cb5e7d58ded7996e89cfa545f1c9ca7a2f13ef4cf39116b53268a585_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*     <?php if (!$form->parent && $errors): ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php endif ?>*/
/*     <?php echo $view['form']->block($form, 'form_rows') ?>*/
/*     <?php echo $view['form']->rest($form) ?>*/
/* </div>*/
/* */

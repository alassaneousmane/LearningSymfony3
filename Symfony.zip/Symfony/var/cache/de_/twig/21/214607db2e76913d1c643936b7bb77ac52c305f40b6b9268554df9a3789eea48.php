<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_1b8bfa4dd67d941ff0da12d3753b9c3ab81d91f00e22b8c2cfec31a5bcf5c923 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f859a8749ba22bd3a37ca05bf5372d81f0428403d82fe9d804b29757882616fe = $this->env->getExtension("native_profiler");
        $__internal_f859a8749ba22bd3a37ca05bf5372d81f0428403d82fe9d804b29757882616fe->enter($__internal_f859a8749ba22bd3a37ca05bf5372d81f0428403d82fe9d804b29757882616fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_f859a8749ba22bd3a37ca05bf5372d81f0428403d82fe9d804b29757882616fe->leave($__internal_f859a8749ba22bd3a37ca05bf5372d81f0428403d82fe9d804b29757882616fe_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->label($form) ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */

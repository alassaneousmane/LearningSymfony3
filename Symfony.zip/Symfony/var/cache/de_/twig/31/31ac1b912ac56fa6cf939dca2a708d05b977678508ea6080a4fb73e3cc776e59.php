<?php

/* @Twig/Exception/exception.css.twig */
class __TwigTemplate_1c4efc67b26baf9f1ca44eb51232f493cbc54c34a8eb443aab215321bcf5bce9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_13ffe87ad1225979984b9e37d1934c6f70d20a652ea60f4e4fd73c3b4970582b = $this->env->getExtension("native_profiler");
        $__internal_13ffe87ad1225979984b9e37d1934c6f70d20a652ea60f4e4fd73c3b4970582b->enter($__internal_13ffe87ad1225979984b9e37d1934c6f70d20a652ea60f4e4fd73c3b4970582b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "@Twig/Exception/exception.css.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_13ffe87ad1225979984b9e37d1934c6f70d20a652ea60f4e4fd73c3b4970582b->leave($__internal_13ffe87ad1225979984b9e37d1934c6f70d20a652ea60f4e4fd73c3b4970582b_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */

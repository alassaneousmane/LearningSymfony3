<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_3ca338e4da905a3d1e0e4996b93af4050044b19be21dcb1e9b35942023e9f885 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_01598f4eb0046ce5918ed3461db4ce1da8f2a5c5d63f83eb26b7dd8f82ff5cfd = $this->env->getExtension("native_profiler");
        $__internal_01598f4eb0046ce5918ed3461db4ce1da8f2a5c5d63f83eb26b7dd8f82ff5cfd->enter($__internal_01598f4eb0046ce5918ed3461db4ce1da8f2a5c5d63f83eb26b7dd8f82ff5cfd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_01598f4eb0046ce5918ed3461db4ce1da8f2a5c5d63f83eb26b7dd8f82ff5cfd->leave($__internal_01598f4eb0046ce5918ed3461db4ce1da8f2a5c5d63f83eb26b7dd8f82ff5cfd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'submit')) ?>*/
/* */

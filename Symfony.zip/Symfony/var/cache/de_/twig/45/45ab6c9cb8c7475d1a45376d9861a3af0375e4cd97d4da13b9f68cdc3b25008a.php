<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_f50bdc72eb22a07d54130be032043ae7e062cf836aab4803a492f87f0b63c98b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_eb90992edea4f314296a9dfb4b04e22d5b796ede266a25b42f611e640671fe9c = $this->env->getExtension("native_profiler");
        $__internal_eb90992edea4f314296a9dfb4b04e22d5b796ede266a25b42f611e640671fe9c->enter($__internal_eb90992edea4f314296a9dfb4b04e22d5b796ede266a25b42f611e640671fe9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_eb90992edea4f314296a9dfb4b04e22d5b796ede266a25b42f611e640671fe9c->leave($__internal_eb90992edea4f314296a9dfb4b04e22d5b796ede266a25b42f611e640671fe9c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($form->vars['multipart']): ?>enctype="multipart/form-data"<?php endif ?>*/
/* */

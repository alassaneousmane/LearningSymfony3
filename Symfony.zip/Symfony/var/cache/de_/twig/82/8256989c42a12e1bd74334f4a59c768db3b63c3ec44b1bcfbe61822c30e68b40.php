<?php

/* @OCPlatform/Test/index.html.twig */
class __TwigTemplate_7cdebcf5dba2d8475b256d553234bbece716d4ef00edc296a1034f62c8f6f292 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a38e8dfef8166ff98f206d80f4124605df3764a105caa0523875a1a4f37a44c2 = $this->env->getExtension("native_profiler");
        $__internal_a38e8dfef8166ff98f206d80f4124605df3764a105caa0523875a1a4f37a44c2->enter($__internal_a38e8dfef8166ff98f206d80f4124605df3764a105caa0523875a1a4f37a44c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@OCPlatform/Test/index.html.twig"));

        // line 1
        echo "

<!DOCTYPE html>
<html>
  <head>
    <title>Bienvenue sur ma première page avec OpenClassrooms !</title>
  </head>
  <body>
    <h1>ByeBye World !</h1>
    <hr/>

    <p>
      Le ByeBye World est un grand classique en programmation.
      Il signifie énormément, car cela veut dire que vous avez
      réussi à exécuter le programme pour accomplir une tâche simple :
      afficher ce hello world !
    </p>
  </body>
</html>
";
        
        $__internal_a38e8dfef8166ff98f206d80f4124605df3764a105caa0523875a1a4f37a44c2->leave($__internal_a38e8dfef8166ff98f206d80f4124605df3764a105caa0523875a1a4f37a44c2_prof);

    }

    public function getTemplateName()
    {
        return "@OCPlatform/Test/index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* */
/* */
/* <!DOCTYPE html>*/
/* <html>*/
/*   <head>*/
/*     <title>Bienvenue sur ma première page avec OpenClassrooms !</title>*/
/*   </head>*/
/*   <body>*/
/*     <h1>ByeBye World !</h1>*/
/*     <hr/>*/
/* */
/*     <p>*/
/*       Le ByeBye World est un grand classique en programmation.*/
/*       Il signifie énormément, car cela veut dire que vous avez*/
/*       réussi à exécuter le programme pour accomplir une tâche simple :*/
/*       afficher ce hello world !*/
/*     </p>*/
/*   </body>*/
/* </html>*/
/* */

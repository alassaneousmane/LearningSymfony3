<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_3918c1f75b8ed113ef0807f79cb920cc5682521680b0e02080e560033aa801cc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e93570a29de16b6338cb4d003b71eb576d9965a2e6a1625dc19381d0b8d903aa = $this->env->getExtension("native_profiler");
        $__internal_e93570a29de16b6338cb4d003b71eb576d9965a2e6a1625dc19381d0b8d903aa->enter($__internal_e93570a29de16b6338cb4d003b71eb576d9965a2e6a1625dc19381d0b8d903aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_e93570a29de16b6338cb4d003b71eb576d9965a2e6a1625dc19381d0b8d903aa->leave($__internal_e93570a29de16b6338cb4d003b71eb576d9965a2e6a1625dc19381d0b8d903aa_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (count($errors) > 0): ?>*/
/*     <ul>*/
/*         <?php foreach ($errors as $error): ?>*/
/*             <li><?php echo $error->getMessage() ?></li>*/
/*         <?php endforeach; ?>*/
/*     </ul>*/
/* <?php endif ?>*/
/* */

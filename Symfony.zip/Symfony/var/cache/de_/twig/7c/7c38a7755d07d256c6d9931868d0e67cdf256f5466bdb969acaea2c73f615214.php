<?php

/* @OCPlatform/Advert/view.html.twig */
class __TwigTemplate_9c77f82b782d09d9ac88561e91b0d92842ac0b74d67321547f30807715de635d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5a4602d6d415ac88bcf5051b0d8420d48a7ca1d7af696ec53c33cf5d7e7ab788 = $this->env->getExtension("native_profiler");
        $__internal_5a4602d6d415ac88bcf5051b0d8420d48a7ca1d7af696ec53c33cf5d7e7ab788->enter($__internal_5a4602d6d415ac88bcf5051b0d8420d48a7ca1d7af696ec53c33cf5d7e7ab788_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@OCPlatform/Advert/view.html.twig"));

        // line 2
        echo "
<!DOCTYPE html>
<html>
  <head>
    <title>Affichage de l'annonce ";
        // line 6
        echo twig_escape_filter($this->env, (isset($context["id"]) ? $context["id"] : $this->getContext($context, "id")), "html", null, true);
        echo "</title>
  </head>
  <body style=\"font-family: Times New Roman\">
  <center>
    <h1>Affichage de l'annonce n°";
        // line 10
        echo twig_escape_filter($this->env, (isset($context["id"]) ? $context["id"] : $this->getContext($context, "id")), "html", null, true);
        echo " !</h1>

    <div>
      ";
        // line 14
        echo "      ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "info"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 15
            echo "        <p>Message flash : ";
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</p>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 17
        echo "    </div>

    <p>
      Ici nous pourrons lire l'annonce ayant comme id : ";
        // line 20
        echo twig_escape_filter($this->env, (isset($context["id"]) ? $context["id"] : $this->getContext($context, "id")), "html", null, true);
        echo "<br />
      Mais pour l'instant, nous ne savons pas encore le faire, cela viendra !
    </p>
    </center>
  </body>
</html>
";
        
        $__internal_5a4602d6d415ac88bcf5051b0d8420d48a7ca1d7af696ec53c33cf5d7e7ab788->leave($__internal_5a4602d6d415ac88bcf5051b0d8420d48a7ca1d7af696ec53c33cf5d7e7ab788_prof);

    }

    public function getTemplateName()
    {
        return "@OCPlatform/Advert/view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 20,  55 => 17,  46 => 15,  41 => 14,  35 => 10,  28 => 6,  22 => 2,);
    }
}
/* {# src/OC/PlatformBundle/Resources/view/Advert/view.html.twig #}*/
/* */
/* <!DOCTYPE html>*/
/* <html>*/
/*   <head>*/
/*     <title>Affichage de l'annonce {{ id }}</title>*/
/*   </head>*/
/*   <body style="font-family: Times New Roman">*/
/*   <center>*/
/*     <h1>Affichage de l'annonce n°{{ id }} !</h1>*/
/* */
/*     <div>*/
/*       {# On affiche tous les messages flash dont le nom est « info » #}*/
/*       {% for message in app.session.flashbag.get('info') %}*/
/*         <p>Message flash : {{ message }}</p>*/
/*       {% endfor %}*/
/*     </div>*/
/* */
/*     <p>*/
/*       Ici nous pourrons lire l'annonce ayant comme id : {{ id }}<br />*/
/*       Mais pour l'instant, nous ne savons pas encore le faire, cela viendra !*/
/*     </p>*/
/*     </center>*/
/*   </body>*/
/* </html>*/
/* */

<?php

/* TwigBundle:Exception:exception.css.twig */
class __TwigTemplate_a7aacf5bf8026783a17f52a946506d387f85ac87fed67f51abfca2e5d31d51d8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_664c9748f1fa8a3c8d7bf3e7c20c6bd532cd12938aa053b0ba309dd452014782 = $this->env->getExtension("native_profiler");
        $__internal_664c9748f1fa8a3c8d7bf3e7c20c6bd532cd12938aa053b0ba309dd452014782->enter($__internal_664c9748f1fa8a3c8d7bf3e7c20c6bd532cd12938aa053b0ba309dd452014782_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.css.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_664c9748f1fa8a3c8d7bf3e7c20c6bd532cd12938aa053b0ba309dd452014782->leave($__internal_664c9748f1fa8a3c8d7bf3e7c20c6bd532cd12938aa053b0ba309dd452014782_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */

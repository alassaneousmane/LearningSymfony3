<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_321d8978945e07b76897502cdb23632ef953d3870529009d0eaebbf3b873b200 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3ba0a223aabb1fb73e963617ff4f1847a4356207a0e6ccc7b72acbc8c898f4be = $this->env->getExtension("native_profiler");
        $__internal_3ba0a223aabb1fb73e963617ff4f1847a4356207a0e6ccc7b72acbc8c898f4be->enter($__internal_3ba0a223aabb1fb73e963617ff4f1847a4356207a0e6ccc7b72acbc8c898f4be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3ba0a223aabb1fb73e963617ff4f1847a4356207a0e6ccc7b72acbc8c898f4be->leave($__internal_3ba0a223aabb1fb73e963617ff4f1847a4356207a0e6ccc7b72acbc8c898f4be_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_a518c97d4a140df8f25fcb0eabb0896228fd93c0e8c9422f08f65a774097b644 = $this->env->getExtension("native_profiler");
        $__internal_a518c97d4a140df8f25fcb0eabb0896228fd93c0e8c9422f08f65a774097b644->enter($__internal_a518c97d4a140df8f25fcb0eabb0896228fd93c0e8c9422f08f65a774097b644_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_a518c97d4a140df8f25fcb0eabb0896228fd93c0e8c9422f08f65a774097b644->leave($__internal_a518c97d4a140df8f25fcb0eabb0896228fd93c0e8c9422f08f65a774097b644_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_db07a1c3335891025c06dbcf06c5f3243819e6aba06aace099ad69a3968a8b33 = $this->env->getExtension("native_profiler");
        $__internal_db07a1c3335891025c06dbcf06c5f3243819e6aba06aace099ad69a3968a8b33->enter($__internal_db07a1c3335891025c06dbcf06c5f3243819e6aba06aace099ad69a3968a8b33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_db07a1c3335891025c06dbcf06c5f3243819e6aba06aace099ad69a3968a8b33->leave($__internal_db07a1c3335891025c06dbcf06c5f3243819e6aba06aace099ad69a3968a8b33_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_da5bfdaf6914dd9a5a39bd5a683f46c5feda069aad3ac38eb3478cabe8a74acd = $this->env->getExtension("native_profiler");
        $__internal_da5bfdaf6914dd9a5a39bd5a683f46c5feda069aad3ac38eb3478cabe8a74acd->enter($__internal_da5bfdaf6914dd9a5a39bd5a683f46c5feda069aad3ac38eb3478cabe8a74acd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('routing')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_da5bfdaf6914dd9a5a39bd5a683f46c5feda069aad3ac38eb3478cabe8a74acd->leave($__internal_da5bfdaf6914dd9a5a39bd5a683f46c5feda069aad3ac38eb3478cabe8a74acd_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@WebProfiler/Profiler/layout.html.twig' %}*/
/* */
/* {% block toolbar %}{% endblock %}*/
/* */
/* {% block menu %}*/
/* <span class="label">*/
/*     <span class="icon">{{ include('@WebProfiler/Icon/router.svg') }}</span>*/
/*     <strong>Routing</strong>*/
/* </span>*/
/* {% endblock %}*/
/* */
/* {% block panel %}*/
/*     {{ render(path('_profiler_router', { token: token })) }}*/
/* {% endblock %}*/
/* */

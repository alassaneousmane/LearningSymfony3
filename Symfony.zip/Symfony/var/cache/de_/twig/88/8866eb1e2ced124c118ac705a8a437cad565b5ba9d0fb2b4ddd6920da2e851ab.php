<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_83cdaef6639030edb81885c8d7a823d9dad9ca89bd7e4cdfecdf7907b85334de extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1b50bfe96c16e025eef9f351fba25ca231d1ddeecd2be48ce053b2f328fd6e93 = $this->env->getExtension("native_profiler");
        $__internal_1b50bfe96c16e025eef9f351fba25ca231d1ddeecd2be48ce053b2f328fd6e93->enter($__internal_1b50bfe96c16e025eef9f351fba25ca231d1ddeecd2be48ce053b2f328fd6e93_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_1b50bfe96c16e025eef9f351fba25ca231d1ddeecd2be48ce053b2f328fd6e93->leave($__internal_1b50bfe96c16e025eef9f351fba25ca231d1ddeecd2be48ce053b2f328fd6e93_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <textarea <?php echo $view['form']->block($form, 'widget_attributes') ?>><?php echo $view->escape($value) ?></textarea>*/
/* */

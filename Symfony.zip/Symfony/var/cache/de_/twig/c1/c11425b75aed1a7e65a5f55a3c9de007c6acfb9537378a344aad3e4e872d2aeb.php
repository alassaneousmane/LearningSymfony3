<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_e7850e8f83085cde1f980e62eb71def665fe756125926d3052978eaf71c78d44 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b5edf4217dfa666bb505186d5af66ca310406334e82aaddc5717c17632bb1a89 = $this->env->getExtension("native_profiler");
        $__internal_b5edf4217dfa666bb505186d5af66ca310406334e82aaddc5717c17632bb1a89->enter($__internal_b5edf4217dfa666bb505186d5af66ca310406334e82aaddc5717c17632bb1a89_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_b5edf4217dfa666bb505186d5af66ca310406334e82aaddc5717c17632bb1a89->leave($__internal_b5edf4217dfa666bb505186d5af66ca310406334e82aaddc5717c17632bb1a89_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td></td>*/
/*     <td>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */

<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_f6b292f6c39c780f11769c81e03b515feadd3cbf8d5f45303812e5f5cd58d2c1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_29e38da3ca0e1467e47514cd6c194375942dfa99ffef9be19a1da7ee4e272b54 = $this->env->getExtension("native_profiler");
        $__internal_29e38da3ca0e1467e47514cd6c194375942dfa99ffef9be19a1da7ee4e272b54->enter($__internal_29e38da3ca0e1467e47514cd6c194375942dfa99ffef9be19a1da7ee4e272b54_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_29e38da3ca0e1467e47514cd6c194375942dfa99ffef9be19a1da7ee4e272b54->leave($__internal_29e38da3ca0e1467e47514cd6c194375942dfa99ffef9be19a1da7ee4e272b54_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_rows') ?>*/
/* */

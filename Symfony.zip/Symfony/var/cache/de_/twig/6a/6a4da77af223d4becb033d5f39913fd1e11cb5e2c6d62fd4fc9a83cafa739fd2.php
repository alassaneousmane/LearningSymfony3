<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_4b39d3b12edcfeecb119bfa41dfccaffb1b9f068d6f92fb55904ba7ef48d42e3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ab8a88cc4faccb8b17a300bf525c148a71d313b906eaade345efda9416c6152b = $this->env->getExtension("native_profiler");
        $__internal_ab8a88cc4faccb8b17a300bf525c148a71d313b906eaade345efda9416c6152b->enter($__internal_ab8a88cc4faccb8b17a300bf525c148a71d313b906eaade345efda9416c6152b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_ab8a88cc4faccb8b17a300bf525c148a71d313b906eaade345efda9416c6152b->leave($__internal_ab8a88cc4faccb8b17a300bf525c148a71d313b906eaade345efda9416c6152b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?>*/
/* */

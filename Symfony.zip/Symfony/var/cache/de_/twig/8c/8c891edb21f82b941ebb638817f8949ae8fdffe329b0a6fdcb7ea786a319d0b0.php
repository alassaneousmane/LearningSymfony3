<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_2506b47c927bd62840961c0f776e9cfc33827243a2f25103c4f3a351ec28b57b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_45aff5d9cb5be05bd61e04796264f13464b7bb624640c41b94f5a26aee49585c = $this->env->getExtension("native_profiler");
        $__internal_45aff5d9cb5be05bd61e04796264f13464b7bb624640c41b94f5a26aee49585c->enter($__internal_45aff5d9cb5be05bd61e04796264f13464b7bb624640c41b94f5a26aee49585c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_45aff5d9cb5be05bd61e04796264f13464b7bb624640c41b94f5a26aee49585c->leave($__internal_45aff5d9cb5be05bd61e04796264f13464b7bb624640c41b94f5a26aee49585c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr style="display: none">*/
/*     <td colspan="2">*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */

<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_aa20ae4fd5aaa22ef18d0a4d679362efd698734a242aebcdd0e2dcec805296c0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5792710eb4526d6b8f944ab82ddb52a69da81cc8582387cf6469027988e850c5 = $this->env->getExtension("native_profiler");
        $__internal_5792710eb4526d6b8f944ab82ddb52a69da81cc8582387cf6469027988e850c5->enter($__internal_5792710eb4526d6b8f944ab82ddb52a69da81cc8582387cf6469027988e850c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_5792710eb4526d6b8f944ab82ddb52a69da81cc8582387cf6469027988e850c5->leave($__internal_5792710eb4526d6b8f944ab82ddb52a69da81cc8582387cf6469027988e850c5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'url')) ?>*/
/* */

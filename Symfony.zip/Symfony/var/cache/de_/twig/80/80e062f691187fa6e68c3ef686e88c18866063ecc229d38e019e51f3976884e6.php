<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_9b7fc7148c2136567c3c76434c60516356f048a53fb58e3d107573cb85db71c9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1a8adbe3e466acb09485f802c48bfefe12e662f2fb5299d835a122ec5f93439b = $this->env->getExtension("native_profiler");
        $__internal_1a8adbe3e466acb09485f802c48bfefe12e662f2fb5299d835a122ec5f93439b->enter($__internal_1a8adbe3e466acb09485f802c48bfefe12e662f2fb5299d835a122ec5f93439b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_1a8adbe3e466acb09485f802c48bfefe12e662f2fb5299d835a122ec5f93439b->leave($__internal_1a8adbe3e466acb09485f802c48bfefe12e662f2fb5299d835a122ec5f93439b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($compound): ?>*/
/* <?php echo $view['form']->block($form, 'form_widget_compound')?>*/
/* <?php else: ?>*/
/* <?php echo $view['form']->block($form, 'form_widget_simple')?>*/
/* <?php endif ?>*/
/* */

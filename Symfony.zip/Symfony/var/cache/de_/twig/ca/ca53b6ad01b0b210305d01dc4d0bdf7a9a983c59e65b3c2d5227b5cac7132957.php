<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_728fe896e542ce9976eed4d3ac5e42beb6f5f4c72cf8410cfb82129699739a6a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_414bc8f5b81866b748f115ba65c7747f4f74d203fa37608fc7840bcb38e7f25e = $this->env->getExtension("native_profiler");
        $__internal_414bc8f5b81866b748f115ba65c7747f4f74d203fa37608fc7840bcb38e7f25e->enter($__internal_414bc8f5b81866b748f115ba65c7747f4f74d203fa37608fc7840bcb38e7f25e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_414bc8f5b81866b748f115ba65c7747f4f74d203fa37608fc7840bcb38e7f25e->leave($__internal_414bc8f5b81866b748f115ba65c7747f4f74d203fa37608fc7840bcb38e7f25e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?> %*/
/* */

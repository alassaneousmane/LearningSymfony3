<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_0f88ad7c1646609e04c1e9194c24ebecac30a3f28832d015c81ad71caabb5c84 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ce3d69b02598b5e98dda66a34e174ecad902771ad460f4c20d15cc8fb2148e56 = $this->env->getExtension("native_profiler");
        $__internal_ce3d69b02598b5e98dda66a34e174ecad902771ad460f4c20d15cc8fb2148e56->enter($__internal_ce3d69b02598b5e98dda66a34e174ecad902771ad460f4c20d15cc8fb2148e56_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_ce3d69b02598b5e98dda66a34e174ecad902771ad460f4c20d15cc8fb2148e56->leave($__internal_ce3d69b02598b5e98dda66a34e174ecad902771ad460f4c20d15cc8fb2148e56_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="radio"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     value="<?php echo $view->escape($value) ?>"*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */

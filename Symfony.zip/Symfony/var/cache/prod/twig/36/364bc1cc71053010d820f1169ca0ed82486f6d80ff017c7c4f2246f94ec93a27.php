<?php

/* @OCPlatform/Advert/add.html.twig */
class __TwigTemplate_242d49999fd8474aa8d918852a843d78500f995b4ecbeb2011c0b04560e4125f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "
<!DOCTYPE html>
<html>
  <head>
    <title>Affichage de l'annonce ";
        // line 6
        echo twig_escape_filter($this->env, (isset($context["id"]) ? $context["id"] : null), "html", null, true);
        echo "</title>
  </head>
  <body style=\"color:blue; font-family: Times New Roman\">
  <center>
    <h1>Affichage de l'annonce n°";
        // line 10
        echo twig_escape_filter($this->env, (isset($context["id"]) ? $context["id"] : null), "html", null, true);
        echo " !</h1>

    <div>
      ";
        // line 14
        echo "      ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "session", array()), "flashbag", array()), "get", array(0 => "info"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 15
            echo "        <p>Message flash : ";
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</p>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 17
        echo "    </div>

    <p>
      Ici nous pourrons lire l'annonce ayant comme id : ";
        // line 20
        echo twig_escape_filter($this->env, (isset($context["id"]) ? $context["id"] : null), "html", null, true);
        echo "<br />
      Mais pour l'instant, nous ne savons pas encore le faire, cela viendra !
    </p>
    </center>
  </body>
</html>
";
    }

    public function getTemplateName()
    {
        return "@OCPlatform/Advert/add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 20,  52 => 17,  43 => 15,  38 => 14,  32 => 10,  25 => 6,  19 => 2,);
    }
}
/* {# src/OC/PlatformBundle/Resources/view/Advert/view.html.twig #}*/
/* */
/* <!DOCTYPE html>*/
/* <html>*/
/*   <head>*/
/*     <title>Affichage de l'annonce {{ id }}</title>*/
/*   </head>*/
/*   <body style="color:blue; font-family: Times New Roman">*/
/*   <center>*/
/*     <h1>Affichage de l'annonce n°{{ id }} !</h1>*/
/* */
/*     <div>*/
/*       {# On affiche tous les messages flash dont le nom est « info » #}*/
/*       {% for message in app.session.flashbag.get('info') %}*/
/*         <p>Message flash : {{ message }}</p>*/
/*       {% endfor %}*/
/*     </div>*/
/* */
/*     <p>*/
/*       Ici nous pourrons lire l'annonce ayant comme id : {{ id }}<br />*/
/*       Mais pour l'instant, nous ne savons pas encore le faire, cela viendra !*/
/*     </p>*/
/*     </center>*/
/*   </body>*/
/* </html>*/
/* */

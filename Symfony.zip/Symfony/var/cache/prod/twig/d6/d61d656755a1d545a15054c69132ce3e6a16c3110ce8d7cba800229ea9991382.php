<?php

/* OCPlatformBundle:Advert:index.html.twig */
class __TwigTemplate_ce76c9d82c20cc7344725de71a6c68cafd5dfb347a5a04171aaaad3a47df8bb3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
  <head>
    <title>Annonce N° ";
        // line 4
        echo twig_escape_filter($this->env, strip_tags((isset($context["author"]) ? $context["author"] : null)), "html", null, true);
        echo "!</title>
    <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css\">
    <style>
    p
    {
    color : blue;
    }
    </style>
  </head>
  <body>
    

    <p>
    <center>
 <div class=\"main-content\">
 <div class=\"jumbotron\">
       <h1> Hello Annonce N° ";
        // line 20
        echo twig_escape_filter($this->env, (isset($context["pageId"]) ? $context["pageId"] : null), "html", null, true);
        echo " </h1> 
            </center>
    </p>
    <p> ";
        // line 24
        echo "           Il faut avoir au moins 12 ans pour regarder ce film
        ";
        // line 26
        echo "          Ok, bon film!
        ";
        // line 28
        echo "          Un peu vieux pour ce film non ?
        ";
        // line 30
        echo "        </p><p><strong>Boucle</strong>
        <ul>
        ";
        // line 33
        echo "          <li> ";
        echo " </li>
        ";
        // line 35
        echo "          <li>Pas d'utilisateur trouvé</li>
        ";
        // line 37
        echo "        </ul>
        </p>
        </div>
        </div>
    <footer> Responsable du site : <strong> ";
        // line 41
        echo twig_escape_filter($this->env, (isset($context["webmaster"]) ? $context["webmaster"] : null), "html", null, true);
        echo " </strong></footer>
     <script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>

    <script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js\"></script>
  </body>
</html>
";
    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  75 => 41,  69 => 37,  66 => 35,  62 => 33,  58 => 30,  55 => 28,  52 => 26,  49 => 24,  43 => 20,  24 => 4,  19 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*   <head>*/
/*     <title>Annonce N° {{ author|striptags  }}!</title>*/
/*     <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">*/
/*     <style>*/
/*     p*/
/*     {*/
/*     color : blue;*/
/*     }*/
/*     </style>*/
/*   </head>*/
/*   <body>*/
/*     */
/* */
/*     <p>*/
/*     <center>*/
/*  <div class="main-content">*/
/*  <div class="jumbotron">*/
/*        <h1> Hello Annonce N° {{ pageId  }} </h1> */
/*             </center>*/
/*     </p>*/
/*     <p> {# if member.age < 12 #}*/
/*            Il faut avoir au moins 12 ans pour regarder ce film*/
/*         {# elseif member.age < 18 #}*/
/*           Ok, bon film!*/
/*         {# else #}*/
/*           Un peu vieux pour ce film non ?*/
/*         {# endif #}*/
/*         </p><p><strong>Boucle</strong>*/
/*         <ul>*/
/*         {# for member in liste_members #}*/
/*           <li> {# member.pseudo #} </li>*/
/*         {# else #}*/
/*           <li>Pas d'utilisateur trouvé</li>*/
/*         {# endfor #}*/
/*         </ul>*/
/*         </p>*/
/*         </div>*/
/*         </div>*/
/*     <footer> Responsable du site : <strong> {{ webmaster }} </strong></footer>*/
/*      <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>*/
/* */
/*     <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>*/
/*   </body>*/
/* </html>*/
/* */

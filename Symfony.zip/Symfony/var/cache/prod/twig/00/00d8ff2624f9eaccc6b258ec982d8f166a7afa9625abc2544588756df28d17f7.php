<?php

/* TwigBundle:Exception:error404.html.twig */
class __TwigTemplate_959ba8f443af69ddf4c52eb3689657df2d84e5b6f223acba9a6aaed78244fba8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error404.html.twig";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}

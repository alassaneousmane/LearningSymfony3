<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_7d57b5dccbffa510abae47ff818fe633bcea6aea45c5a4d73d109aa277293730 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}

<?php

// src/OC/PlatformBundle/Controller/AdvertController.php

namespace OC\PlatformBundle\Controller;

// N'oubliez pas ce use :
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
//use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class AdvertController extends Controller
{
	public function menuAction($limit)
	{
		// On fixe en dur une liste ici, bien entendu par la suite, on la récupérera depuis la BDD !
		$listAdverts = array(
			array('id' => 2, 'title' => 'Recherche développeur Symfony'),
			array('id' => 5, 'title' => 'Mission de webmaster'),
			array('id' => 9, 'title' => 'Offre de stages webdesigner')
			);
		return $this->render('OCPlatformBundle:Advert:menu.html.twig', array(
			// Tout l'interêt est ici : le contrôleur passe les variables necessaires au template !
			'listAdverts' => $listAdverts));
	}
	// La route fait appel à OCPlatformBundle:Advert:view,

  // on doit donc définir la méthode viewAction.

  // On donne à cette méthode l'argument $id, pour

  // correspondre au paramètre {id} de la route

  public function viewAction($id, Request $request)

  {
  	$advert = array(
      'title'   => 'Recherche développpeur Symfony2 ou Administrateur réseaux et systèmes',
      'id'      => $id,
      'author'  => 'Alexandre',
      'content' => 'Nous recherchons un développeur Symfony2 débutant sur Lyon. Blabla…',
      'date'    => new \Datetime()
    );
    return $this->render('OCPlatformBundle:Advert:view.html.twig', array(
      'advert' => $advert

    ));

  }
   // On récupère tous les paramètres en arguments de la méthode

    public function viewSlugAction($slug, $year, $format)

    {

        return new Response(

            "On pourrait afficher l'annonce correspondant au

            slug '".$slug."', créée en ".$year." et au format ".$format."."

        );

    }
    public function indexAction($page)
    {
      //On a donc accès au container
      $mailer = $this->container->get('mailer');
      // On peut m'envoyer des mails

    	// On ne sait combien de pages il y a
    	// Mais on sait qu'une page doit être supérieure à 1
    	  if ($page < 1) {
           // On déclenche une exception NotFoundHttpException, cela va afficher
         // une page d'erreur 404 (qu'on pourra personnaliser plus tard d'ailleurs)
             throw new NotFoundHttpException('Page "'.$page.'" inexistante.');
          }
    	
    // Notre liste d'annonce en dur

    $listAdverts = array(
      array(
        'title'   => 'Recherche développpeur Symfony',
        'id'      => 1,
        'author'  => 'Alexandre',
        'content' => 'Nous recherchons un développeur Symfony débutant sur Lyon. Blabla…',
        'date'    => new \Datetime()),
      array(
        'title'   => 'Mission de webmaster',
        'id'      => 2,
        'author'  => 'Hugo',
        'content' => 'Nous recherchons un webmaster capable de maintenir notre site internet. Blabla…',
        'date'    => new \Datetime()),
      array(
        'title'   => 'Offre de stage web-designer',
        'id'      => 3,
        'author'  => 'Mathieu',
        'content' => 'Nous proposons un poste pour webdesigner. Blabla…',
        'date'    => new \Datetime()),
      array(
        'title' => 'Recherche Apprenti développeur web Symfony-ParisSud',
        'id' => 4,
        'author' => 'Ousmane ALASSANE',
        'content' => 'Nous recherchons un jeune développeur capable de réaliser des sites internet avec la programmation orientée objet',
        'date' => new \Datetime()
        )
    );
    // Et modifiez le 2nd argument pour injecter notre liste
    return $this->render('OCPlatformBundle:Advert:index.html.twig', array(
      'listAdverts' => $listAdverts
    ));
}
             
    public function addAction($id, Request $request) 
    {
      //On récupère le service
      $antispam = $this->container->get('oc_platform.antispam');
      // Je pars du principe que $text contient un texte quelconque
      $texte = ".....Votre message a été détecté comme spamVotre message a été détecté comme spamVotre message a été détecté comme spamVotre message a été détecté comme spam";
      if($antispam->isSpam($texte))
      {
        throw new \Exception("Votre message a été détecté comme spam");
        
      }
    	// On va prendre la session
    	$session = $request->getSession();

    	// Si l'annonce est bien enregistrée
    	$session->getFlashBag()->add('info', 'Annonce bien enregistrée!');
    	// Le flashbag est ce qui contient les messages flash dans la session
    	// Il peut aussi contenir plusieurs messages
    	$session->getFlashBag()->add('info', 'Oui, oui l\'annonce est bien enregistrée!');
    	// On récupère le contenu de la variable session 'user_id'
    	$userId = $session->get('user_id');
    	$userName = $session->get('username');
    	// Puis on redirige vers la page de visualisation de cette annonce
    	return $this->redirectToRoute('oc_platform_view', array('id' => $id));
    	// La gestion d'un formulaire est particulière mais l'idée est la suivante

    	// Si la requete est en POST, c'est que le visiteur a soumis le formulaire
    	if($request->isMethod('POST')) {

    		// Ici on s'occupera de la creation et de la gestion du formulaire
    		$request->getSession()->getFlashBag()->add('notice', 'Annonce bien enregistré');
    		// Puis on redirige vers la page de visualisation de cette annonce
    		$this->redirectToRoute('oc_platform_view', array('id' =>  5));
    	} 
    	// Si on n'est pas en POST, on affiche le formulaire
    	// return $this->render('OCPlatformBundle:Advert:add.html.twig', array('id' => $id));
  		//$session = $request->getSession();
  		// Biensûr, cette méthode doit réellement ajouté une annonce

  		// Mais faisons comme si c'est le cas
  		//$session->getFlashBag()->add('info', 'Annonce bien enregistré');
  		 // Le « flashBag » est ce qui contient les messages flash dans la session
    	// Il peut bien sûr contenir plusieurs messages :
   		//$session->getFlashBag()->add('info', 'Oui oui, elle est bien enregistrée !');
   		   // Puis on redirige vers la page de visualisation de cette Annonce
    //	return $this->redirectToRoute('oc_platform_view', array('id' => 5));
    }
    public function editAction($id, Request $request) {
    	// Ici, on récupère l'annonce correspond à l'id

    	//Même mécanisme que pour l'ajout
    	//if($request->isMethod('POST')) {
    	//	$request->getSession()->getFlashBag()->add('notic','Annonce bien modifiée.');
    	//	return $this->redirectToRoute('oc_platform_view', array('id', 5));
    	//}
    	//return $this->render('OCPlatformBundle:Advert:edit.html.twig');
    	 $advert = array(
	      'title'   => 'Recherche développpeur Symfony',
	      'id'      => $id,
	      'author'  => 'Alexandre',
	      'content' => 'Nous recherchons un développeur Symfony débutant sur Lyon. Blabla…',
	      'date'    => new \Datetime()
    	);
	    return $this->render('OCPlatformBundle:Advert:edit.html.twig', array(
	      'advert' => $advert
	    ));
    }
    public function deleteAction($id) 
    {
    	// Ici, on récupère l'annonce correspond à l'id
    	// Ici, on gérera la suppression de l'annonce en question
    	return $this->render('OCPlatformBundle:Advert:delete.html.twig');
    }

    // OussouAndOummouIndex
    public function OussouOummouAction(){
      return $this->render('OCPlatformBundle:Advert:OussouOummou.html.twig');
    }
}
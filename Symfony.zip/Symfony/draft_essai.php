<?php 
echo "Bonjour";